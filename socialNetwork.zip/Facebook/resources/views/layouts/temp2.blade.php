<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>NxN System</title>
    <link rel="icon" href="{{asset('images/fav1.png')}}" type="image/png" sizes="32x32">
    <link rel="stylesheet" href="{{asset('css/main.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/weather-icons.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/toast-notification.css')}}">
    <link rel="stylesheet" href="{{asset('css/page-tour.css')}}">
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
    <link rel="stylesheet" href="{{asset('css/color.css')}}">
    <link rel="stylesheet" href="{{asset('css/nxnStyle.css')}}">
    <link rel="stylesheet" href="{{asset('css/responsive.css')}}">
    <link rel="stylesheet" href="{{asset('css/group_chat.css')}}">

</head>

<body>
    <div class="wavy-wraper">
        <div class="wavy">
            <span style="--i:1;">p</span>
            <span style="--i:2;">i</span>
            <span style="--i:3;">t</span>
            <span style="--i:4;">n</span>
            <span style="--i:5;">i</span>
            <span style="--i:6;">k</span>
            <span style="--i:7;">.</span>
            <span style="--i:8;">.</span>
            <span style="--i:9;">.</span>
        </div>
    </div>
    <div class="theme-layout">

        <div class="postoverlay"></div>

        <div class="responsive-header">
            <div class="mh-head first Sticky">
                <span class="mh-btns-left">
                    <a class="" href="#menu"><i class="fa fa-align-justify"></i></a>
                </span>
                <span class="mh-text">
                    <a href="newsfeed.html" title=""><img src="{{asset('images/logo2.png')}}" alt=""></a>
                </span>
                <span class="mh-btns-right">
                    <a class="fa fa-sliders" href="#shoppingbag"></a>
                </span>
            </div>
            <div class="mh-head second">
                <form class="mh-form">
                    <input placeholder="search" />
                    <a href="#/" class="fa fa-search"></a>
                </form>
            </div>
        </div><!-- responsive header -->

        <div class="topbar stick border-bottom border-danger">
            <div class="logo">
                <a title="" href="{{route('home')}}"><img src="{{asset('images/nxn_system_light.png')}}" alt=""></a>
            </div>
            <div class="top-area">
                <div class="main-menu">
                    <span>
                        <i class="fa fa-braille"></i>
                    </span>
                </div>
                <div class="top-search">
                    <form method="post" class="">
                        <input type="text" placeholder="Search People, Pages, Groups etc">
                        <button data-ripple><i class="ti-search"></i></button>
                    </form>
                </div>
                <div class="page-name">
                    <span>Newsfeed</span>
                </div>
                <ul class="setting-area">
                    <li><a href="newsfeed.html" title="Home" data-ripple=""><i class="fa fa-home"></i></a></li>
                    <li>
                        <a href="#" title="Friend Requests" data-ripple="">
                            <i class="fa fa-user"></i><em class="bg-red count-request">{{count($friend_request)}}</em>
                        </a>
                        <div class="dropdowns">
                            <span><em class="count-request">{{count($friend_request)}}</em> New Requests <a href="#" title="">View all Requests</a></span>
                            <ul id='nxn-request-area' class="drops-menu">
                                @foreach($friend_request as $i)
                                <li>
                                    <div>
                                        <figure style='height:40px;width:40px'>
                                            <img class='w-100 h-100 img-fluid' src="{{asset($i['user_img'])}}" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">{{$i['user_name']}}</a></h6>
                                            <span><b>Amy</b> is mutule friend</span>
                                            <i>{{$i['time']}}</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title="" data-url="{{route('agree')}}" data-val={{$i['rel_id']}} data-res={{$i['res_id']}} class='nxn_Agree'><i class="fa fa-heart"></i></a>

                                            <a href="#" title="" data-url="{{route('refuse')}}" data-res={{$i['res_id']}} class='nxn_refuse'><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                            <a href="friend-requests.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="Notification" data-ripple="">
                            <i class="fa fa-bell"></i><em class="bg-purple">7</em>
                        </a>
                        <div class="dropdowns">
                            <span>4 New Notifications <a href="#" title="">Mark all as read</a></span>
                            <ul class="drops-menu">
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-1.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>sarah Loren</h6>
                                            <span>commented on your new profile status</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-2.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Jhon doe</h6>
                                            <span>Nicholas Grissom just became friends. Write on his wall.</span>
                                            <i>4 hours ago</i>
                                            <figure>
                                                <span>Today is Marina Valentine’s Birthday! wish for celebrating</span>
                                                <img src="{{asset('images/birthday.png')}}" alt="">
                                            </figure>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-3.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Andrew</h6>
                                            <span>commented on your photo.</span>
                                            <i>Sunday</i>
                                            <figure>
                                                <span>"Celebrity looks Beautiful in that outfit! We should see each"</span>
                                                <img src="{{asset('images/resources/admin.jpg')}}" alt="">
                                            </figure>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-4.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Tom cruse</h6>
                                            <span>nvited you to attend to his event Goo in</span>
                                            <i>May 19</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-5.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Amy</h6>
                                            <span>Andrew Changed his profile picture. </span>
                                            <i>dec 18</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                            </ul>
                            <a href="notifications.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="Messages" data-ripple=""><i class="fa fa-commenting"></i><em class="bg-blue">9</em></a>
                        <div class="dropdowns">
                            <span>5 New Messages <a href="#" title="">Mark all as read</a></span>
                            <ul class="drops-menu">
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-1.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>sarah Loren</h6>
                                            <span><i class="ti-check"></i> Hi, how r u dear ...?</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-2.jpg')}}" alt="">
                                            <span class="status f-offline"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Jhon doe</h6>
                                            <span><i class="ti-check"></i> We’ll have to check that at the office and see if the client is on board with</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-3.jpg')}}" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Andrew</h6>
                                            <span> <i class="fa fa-paperclip"></i>Hi Jack's! It’s Diana, I just wanted to let you know that we have to reschedule..</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-4.jpg')}}" alt="">
                                            <span class="status f-offline"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Tom cruse</h6>
                                            <span><i class="ti-check"></i> Great, I’ll see you tomorrow!.</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="{{asset('images/resources/thumb-5.jpg')}}" alt="">
                                            <span class="status f-away"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Amy</h6>
                                            <span><i class="fa fa-paperclip"></i> Sed ut perspiciatis unde omnis iste natus error sit </span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                            </ul>
                            <a href="chat-messenger.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li><a href="#" title="Languages" data-ripple=""><i class="fa fa-globe"></i><em>EN</em></a>
                        <div class="dropdowns languages">
                            <div data-gutter="10" class="row">
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/UK.png')}}">English(UK)
                                            </a>
                                        </li>
                                        <li class="active">
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/US.png')}}">English(US)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/DE.png')}}">Deutsch
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/NED.png')}}">Nederlands
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/FR.png')}}">Français
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/SP.png')}}">Español
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/ARG.png')}}">Español (AR)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/IT.png')}}">Italiano
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/PT.png')}}">Português (PT)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/BR.png')}}">Português (BR)
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/FIN.png')}}">Suomi
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/SW.png')}}">Svenska
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/DEN.png')}}">Dansk
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/CZ.png')}}">Čeština
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/HUN.png')}}">Magyar
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/ROM.png')}}">Română
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/JP.png')}}">日本語
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/CN.png')}}">简体中文
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/PL.png')}}">Polski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/GR.png')}}">Ελληνικά
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/TUR.png')}}">Türkçe
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/BUL.png')}}">Български
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/ARB.png')}}">العربية
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/KOR.png')}}">한국어
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/ISR.png')}}">עברית
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/LAT.png')}}">Latviski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/UKR.png')}}">Українська
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/IND.png')}}">Bahasa Indonesia
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/MAL.png')}}">Bahasa Malaysia
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/TAI.png')}}">ภาษาไทย
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/CRO.png')}}">Hrvatski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/LIT.png')}}">Lietuvių
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/SLO.png')}}">Slovenčina
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/SERB.png')}}">Srpski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/SLOVE.png')}}">Slovenščina
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/NAM.png')}}">Tiếng Việt
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/PHI.png')}}">Filipino
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/ICE.png')}}">Íslenska
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/EST.png')}}">Eesti
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="{{asset('images/flags/RU.png')}}">Русский
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a href="#" title="Help" data-ripple=""><i class="fa fa-question-circle"></i></a>
                        <div class="dropdowns helps">
                            <span>Quick Help</span>
                            <form method="post">
                                <input type="text" placeholder="How can we help you?">
                            </form>
                            <span>Help with this page</span>
                            <ul class="help-drop">
                                <li><a href="forum.html" title=""><i class="fa fa-book"></i>Community & Forum</a></li>
                                <li><a href="faq.html" title=""><i class="fa fa-question-circle-o"></i>FAQs</a></li>
                                <li><a href="career.html" title=""><i class="fa fa-building-o"></i>Carrers</a></li>
                                <li><a href="privacy.html" title=""><i class="fa fa-pencil-square-o"></i>Terms & Policy</a></li>
                                <li><a href="#" title=""><i class="fa fa-map-marker"></i>Contact</a></li>
                                <li><a href="#" title=""><i class="fa fa-exclamation-triangle"></i>Report a Problem</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <div class="user-img">
                    <h5>@php echo (Auth::user()->name); @endphp</h5>
                    <img class='img-fluid avatar_img' src="{{asset(Auth::user()->user_info->Avatar_pic)}}" alt="">
                    <span class="status f-online"></span>
                    <div class="user-setting">

                        <ul class="log-out">
                            <li><a href="{{url('user/setting')}}" title=""><i class="ti-user"></i> view profile</a></li>
                            <li>
                                <!-- <a href="logout.html" title=""><i class="ti-power-off"></i>log out</a> -->
                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">

                                    <i class="ti-power-off"></i>log out</a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <span class="px-2"> <a href="chat-msg"><i class='fa fa-facebook-f'></i></a></span>
                <span class="ti-settings main-menu" data-ripple=""></span>
            </div>
            <nav>
                <ul class="nav-list">
                    <h3>Function coming soon</h3>
                </ul>

            </nav><!-- nav menu -->
        </div><!-- topbar -->
        @yield('sidebar-right')
        @yield('content')



        <!-- left sidebar menu -->

        <div class="bottombar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <span class="copyright">© Pitnik 2020. All rights reserved.</span>
                        <i><img src="{{asset('images/credit-cards.png')}}" alt=""></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="side-panel">
        <h4 class="panel-title">General Setting</h4>
        <form method="post">
            <div class="setting-row">
                <span>use night mode</span>
                <input type="checkbox" id="nightmode1" />
                <label for="nightmode1" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Notifications</span>
                <input type="checkbox" id="switch22" />
                <label for="switch22" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Notification sound</span>
                <input type="checkbox" id="switch33" />
                <label for="switch33" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>My profile</span>
                <input type="checkbox" id="switch44" />
                <label for="switch44" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Show profile</span>
                <input type="checkbox" id="switch55" />
                <label for="switch55" data-on-label="ON" data-off-label="OFF"></label>
            </div>
        </form>
        <h4 class="panel-title">Account Setting</h4>
        <form method="post">
            <div class="setting-row">
                <span>Sub users</span>
                <input type="checkbox" id="switch66" />
                <label for="switch66" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>personal account</span>
                <input type="checkbox" id="switch77" />
                <label for="switch77" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Business account</span>
                <input type="checkbox" id="switch88" />
                <label for="switch88" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Show me online</span>
                <input type="checkbox" id="switch99" />
                <label for="switch99" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Delete history</span>
                <input type="checkbox" id="switch101" />
                <label for="switch101" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Expose author name</span>
                <input type="checkbox" id="switch111" />
                <label for="switch111" data-on-label="ON" data-off-label="OFF"></label>
            </div>
        </form>
    </div><!-- side panel -->

    <div class="popup-wraper2">
        <div class="popup post-sharing">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <select data-placeholder="Share to friends..." multiple class="chosen-select multi">
                        <option>Share in your feed</option>
                        <option>Share in friend feed</option>
                        <option>Share in a page</option>
                        <option>Share in a group</option>
                        <option>Share in message</option>
                    </select>
                    <div class="post-status">
                        <span><i class="fa fa-globe"></i></span>
                        <ul>
                            <li><a href="#" title=""><i class="fa fa-globe"></i> Post Globaly</a></li>
                            <li><a href="#" title=""><i class="fa fa-user"></i> Post Private</a></li>
                            <li><a href="#" title=""><i class="fa fa-user-plus"></i> Post Friends</a></li>
                        </ul>
                    </div>
                </div>
                <div class="postbox">
                    <div class="post-comt-box">
                        <form method="post">
                            <input type="text" placeholder="Search Friends, Pages, Groups, etc....">
                            <textarea placeholder="Say something about this..."></textarea>
                            <div class="add-smiles">
                                <span title="add icon" class="em em-expressionless"></span>
                                <div class="smiles-bunch">
                                    <i class="em em---1"></i>
                                    <i class="em em-smiley"></i>
                                    <i class="em em-anguished"></i>
                                    <i class="em em-laughing"></i>
                                    <i class="em em-angry"></i>
                                    <i class="em em-astonished"></i>
                                    <i class="em em-blush"></i>
                                    <i class="em em-disappointed"></i>
                                    <i class="em em-worried"></i>
                                    <i class="em em-kissing_heart"></i>
                                    <i class="em em-rage"></i>
                                    <i class="em em-stuck_out_tongue"></i>
                                </div>
                            </div>

                            <button type="submit"></button>
                        </form>
                    </div>
                    <figure><img src="{{asset('images/resources/share-post.jpg')}}" alt=""></figure>
                    <div class="friend-info">
                        <figure>
                            <img alt="" src="{{asset('images/resources/admin.jpg')}}">
                        </figure>
                        <div class="friend-name">
                            <ins><a title="" href="time-line.html">Jack Carter</a> share <a title="" href="#">link</a></ins>
                            <span>Yesterday with @Jack Piller and @Emily Stone at the concert of # Rock'n'Rolla in Ontario.</span>
                        </div>
                    </div>
                    <div class="share-to-other">
                        <span>Share to other socials</span>
                        <ul>
                            <li><a class="facebook-color" href="#" title=""><i class="fa fa-facebook-square"></i></a></li>
                            <li><a class="twitter-color" href="#" title=""><i class="fa fa-twitter-square"></i></a></li>
                            <li><a class="dribble-color" href="#" title=""><i class="fa fa-dribbble"></i></a></li>
                            <li><a class="instagram-color" href="#" title=""><i class="fa fa-instagram"></i></a></li>
                            <li><a class="pinterest-color" href="#" title=""><i class="fa fa-pinterest-square"></i></a></li>
                        </ul>
                    </div>
                    <div class="copy-email">
                        <span>Copy & Email</span>
                        <ul>
                            <li><a href="#" title="Copy Post Link"><i class="fa fa-link"></i></a></li>
                            <li><a href="#" title="Email this Post"><i class="fa fa-envelope"></i></a></li>
                        </ul>
                    </div>
                    <div class="we-video-info">
                        <ul>
                            <li>
                                <span title="" data-toggle="tooltip" class="views" data-original-title="views">
                                    <i class="fa fa-eye"></i>
                                    <ins>1.2k</ins>
                                </span>
                            </li>
                            <li>
                                <span title="" data-toggle="tooltip" class="views" data-original-title="views">
                                    <i class="fa fa-share-alt"></i>
                                    <ins>20k</ins>
                                </span>
                            </li>
                        </ul>
                        <button class="main-btn color" data-ripple="">Submit</button>
                        <button class="main-btn cancel" data-ripple="">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- share popup -->

    <div class="popup-wraper3">
        <div class="popup">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <h5>Report Post</h5>
                </div>
                <div class="Rpt-meta">
                    <span>We're sorry something's wrong. How can we help?</span>
                    <form method="post" class="c-form">
                        <div class="form-radio">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio" checked="checked"><i class="check-box"></i>It's spam or abuse
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>It breaks r/technology's rules
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>Not Related
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>Other issues
                                </label>
                            </div>
                        </div>
                        <div>
                            <label>Write about Report</label>
                            <textarea placeholder="write someting about Post" rows="2"></textarea>
                        </div>
                        <div>
                            <button data-ripple="" type="submit" class="main-btn">Submit</button>
                            <a href="#" data-ripple="" class="main-btn3 cancel">Close</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- report popup -->

    <div class="popup-wraper1">
        <div class="popup direct-mesg">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <h5>Send Message</h5>
                </div>
                <div class="send-message">
                    <form method="post" class="c-form">
                        <input type="text" placeholder="Sophia">
                        <textarea placeholder="Write Message"></textarea>
                        <button type="submit" class="main-btn">Send</button>
                    </form>
                    <div class="add-smiles">
                        <div class="uploadimage">
                            <i class="fa fa-image"></i>
                            <label class="fileContainer">
                                <input type="file">
                            </label>
                        </div>
                        <span title="add icon" class="em em-expressionless"></span>
                        <div class="smiles-bunch">
                            <i class="em em---1"></i>
                            <i class="em em-smiley"></i>
                            <i class="em em-anguished"></i>
                            <i class="em em-laughing"></i>
                            <i class="em em-angry"></i>
                            <i class="em em-astonished"></i>
                            <i class="em em-blush"></i>
                            <i class="em em-disappointed"></i>
                            <i class="em em-worried"></i>
                            <i class="em em-kissing_heart"></i>
                            <i class="em em-rage"></i>
                            <i class="em em-stuck_out_tongue"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div><!-- send message popup -->

    <div class="modal fade" id="img-comt">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="pop-image">
                                <div class="pop-item">
                                    <figure><img src="{{asset('images/resources/blog-detail.jpg')}}" alt=""></figure>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="user">
                                <figure><img src="{{asset('images/resources/user1.jpg')}}" alt=""></figure>
                                <div class="user-information">
                                    <h4><a href="#" title="">Danile Walker</a></h4>
                                    <span>2 hours ago</span>
                                </div>
                                <a href="#" title="Follow" data-ripple="">Follow</a>
                            </div>
                            <div class="we-video-info">
                                <ul>
                                    <li>
                                        <div title="Like/Dislike" class="likes heart">❤ <span>2K</span></div>
                                    </li>
                                    <li>
                                        <span title="Comments" class="comment">
                                            <i class="fa fa-commenting"></i>
                                            <ins>52</ins>
                                        </span>
                                    </li>

                                    <li>
                                        <span>
                                            <a title="Share" href="#" class="">
                                                <i class="fa fa-share-alt"></i>
                                            </a>
                                            <ins>20</ins>
                                        </span>
                                    </li>
                                </ul>
                                <div class="users-thumb-list">
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Anderw">
                                        <img src="{{asset('images/resources/userlist-1.jpg')}}" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="frank">
                                        <img src="{{asset('images/resources/userlist-2.jpg')}}" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Sara">
                                        <img src="{{asset('images/resources/userlist-3.jpg')}}" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Amy">
                                        <img src="{{asset('images/resources/userlist-4.jpg')}}" alt="">
                                    </a>
                                    <span><strong>You</strong>, <b>Sarah</b> and <a title="" href="#">24+ more</a> liked</span>
                                </div>
                            </div>
                            <div style="display: block;" class="coment-area">
                                <ul class="we-comet">
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="{{asset('images/resources/nearly3.jpg')}}">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Jason borne</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster. please vote this video and like our channel</p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>

                                    </li>
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="{{asset('images/resources/comet-4.jpg')}}">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Sophia</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster.
                                                <i class="em em-smiley"></i>
                                            </p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="{{asset('images/resources/comet-4.jpg')}}">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Sophia</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster.
                                                <i class="em em-smiley"></i>
                                            </p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="showmore underline" title="" href="#">more comments+</a>
                                    </li>
                                    <li class="post-comment">
                                        <div class="comet-avatar">
                                            <img alt="" src="{{asset('images/resources/nearly1.jpg')}}">
                                        </div>
                                        <div class="post-comt-box">
                                            <form method="post">
                                                <textarea placeholder="Post your comment"></textarea>
                                                <div class="add-smiles">
                                                    <div class="uploadimage">
                                                        <i class="fa fa-image"></i>
                                                        <label class="fileContainer">
                                                            <input type="file">
                                                        </label>
                                                    </div>
                                                    <span title="add icon" class="em em-expressionless"></span>
                                                    <div class="smiles-bunch">
                                                        <i class="em em---1"></i>
                                                        <i class="em em-smiley"></i>
                                                        <i class="em em-anguished"></i>
                                                        <i class="em em-laughing"></i>
                                                        <i class="em em-angry"></i>
                                                        <i class="em em-astonished"></i>
                                                        <i class="em em-blush"></i>
                                                        <i class="em em-disappointed"></i>
                                                        <i class="em em-worried"></i>
                                                        <i class="em em-kissing_heart"></i>
                                                        <i class="em em-rage"></i>
                                                        <i class="em em-stuck_out_tongue"></i>
                                                    </div>
                                                </div>

                                                <button type="submit"></button>
                                            </form>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- The Scrolling Modal image with comment -->

    <script src="{{asset('js/main.min.js')}}"></script>
    <script src="{{asset('js/toast-notificatons.js')}}"></script>
    <script src="{{asset('js/page-tourintro.js')}}"></script>
    <script src="{{asset('js/page-tour-init.js')}}"></script>
    <script src="{{asset('js/script.js')}}"></script>
    <script src="{{asset('js/chat.js')}}"></script>
    <script src="{{asset('js/group_chat.js')}}"></script>

    <script src="{{asset('js/temp2.js')}}"></script>
</body>


</html>
