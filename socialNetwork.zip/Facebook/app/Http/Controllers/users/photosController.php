<?php

namespace App\Http\Controllers\users;

use App\Http\Controllers\Controller;
use Facade\FlareClient\View;
use Illuminate\Http\Request;

class photosController extends Controller
{
    function showPhotos(){
        return View('users.photos');
    }
}
