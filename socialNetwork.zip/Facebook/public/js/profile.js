jQuery(document).ready(function($) {
    //loadPost
    $('#btn-add-friend').on('click', function(e) {
        $('#addFriend').submit();
    });
    $('#addFriend').submit(function(e) {
        e.preventDefault()
        var url = $('#addFriend input').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == 0) {
                    $('#btn-add-friend').css('color', 'green');
                } else {
                    console.log(data);
                }

            }
        });
    });

    $('#btn-un-friend').on('click', function(e) {

        $('#unFriend').submit();
    });
    $('#unFriend').submit(function(e) {
        e.preventDefault()
        var url = $('#unFriend input').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == 0) {
                    $('#btn-un-friend i').attr('class', 'fa fa-user-plus');
                } else {
                    console.log(data);
                }
                //console.log(data);
            }
        });
    });
});