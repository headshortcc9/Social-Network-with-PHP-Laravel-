jQuery(document).ready(function($) {
    //loadPost
    var postStatus = 0;
    $('.new-postbox').click(function() {
        postStatus = 1;
    });
    $('#edit-pro').submit(function(e) {
        e.preventDefault()
        var url = $('#edit-pro button').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            processData: false,
            contentType: false,
            data: new FormData(document.getElementById('edit-pro')),
            dataType: "json",
            success: function(data) {
                if (data['error'] != null) {
                    alert(data['error'])
                } else {
                    $('#edit-pro button').html('Complete')
                    $('#edit-pro button').css('background-color', 'green')
                    setTimeout(function() {
                        $('#edit-pro button').html('Save');
                        $('#edit-pro button').css('background-color', '#fa6342');
                    }, 1500);
                }
                //console.log(data);
            }

        });


    });

    //cover-pic
    $('#change-cover-pic input').change(function() {
        $('#change-cover-pic').submit();
    });
    $('#change-cover-pic').submit(function(e) {
        e.preventDefault()
        var url = $('#change-cover-pic input').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == null) {
                    $('.cover_img').attr('src', data['cover_img']);
                } else {
                    alert(data['error']);
                }
                //console.log(data);

            }

        });
    });
    //avatar-pic
    $('#change-avatar-pic input').change(function() {
        $('#change-avatar-pic').submit();
    });
    $('#change-avatar-pic').submit(function(e) {
        e.preventDefault()
        var url = $('#change-avatar-pic input').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == null) {
                    $('#avatar-profile').attr('src', data['avatar_pic']);
                    $('.avatar_img').attr('src', data['avatar_pic']);
                } else {
                    alert(data['error']);
                }
                //console.log(data);
            }
        });
    });
    //formPost
    $('#formPostImage input').change(function() {
        $('#formPostImage').submit();
    });
    $('#formPostImage').submit(function(e) {
        e.preventDefault()
        var url = $('#formPostImage input').attr('data-url');
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: url,
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == null) {
                    var str = "<div class='col-lg-6 col-md-6 col-sm-6 px-1 my-1'>" +
                        "<img src='" + data['post_img'] + "'>" +
                        "<a href=''><i class='fa fa-trash'></i></a>" +
                        " </div>"
                    $('#postnxn-review').append(str);
                    $('#formPostContent input').attr('value', data['dataPath']);
                } else {
                    alert(data['error']);
                }
                console.log(data);
            }
        });
    });

    function removePostImage() {
        var path = $('#postnxn-review img').attr('src');
        if (path != null) {
            $.ajax({
                type: "POST",
                url: "user/removeImage",
                data: {
                    'path': path
                },
                dataType: "json",
                success: function(data) {
                    if (data['status'] == 1) {
                        $('#postnxn-review').empty();
                        $('#formPostContent input').attr('value', '');
                    }
                    console.log(data);
                }
            });
        }
    }
    $('.postoverlay').click(function() {
        var path = $('#postnxn-review img').attr('src');
        var text = $('#formPostContent textarea').val();
        if (postStatus == 1 && (path != null || text != '')) {
            var result = confirm("Discart your post, are you sure ?");
            if (result) {
                var path = $('#postnxn-review img').attr('src');
                removePostImage();
            } else $('.new-postbox').click();
        }
    });
    //remove imagePost
    //FormPost submit
    $('#submitPost').click(function(e) {
        e.preventDefault()
        var path = $('#postnxn-review img').attr('src');
        var text = $('#formPostContent textarea').val();
        if (path == null && text == '') {
            postStatus = 0;
            $('.postoverlay').click();
        } else {
            postStatus = 0;

            $('#formPostContent').submit();
        }
    });

    $('#formPostContent').submit(function(e) {
        e.preventDefault()

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $.ajax({
            type: "POST",
            url: "user/post",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] == 0) {
                    $('#formPostContent textarea').val('');
                    $('#postnxn-review').empty();
                    $('#formPostContent input').attr('value', '');
                    $('.postoverlay').click();
                } else {
                    console.log(data);
                }
                console.log(data);
            }
        });
    });

    $('.nxn_Agree').on('click', function(e) {
        var id = $(this).attr('data-val')
        var url = $(this).attr('data-url')
        var res_id = $(this).attr('data-res')
        $(this).parent().parent().parent().remove();
        $('.count-request').text($('#nxn-request-area li').length)
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: url,
            data: {
                'id': id,
                'res_id': res_id
            },
            dataType: "json",
            success: function(data) {
                if (data['error'] == 0) {

                }
                console.log(data);
            }
        });

    });
    $('.nxn_refuse').on('click', function(e) {

        var url = $(this).attr('data-url')
        var res_id = $(this).attr('data-res')
        $(this).parent().parent().parent().remove();
        $('.count-request').text($('#nxn-request-area li').length)
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: url,
            data: {
                'res_id': res_id
            },
            dataType: "json",
            success: function(data) {
                if (data['error'] == 0) {

                }
                console.log(data);
            }
        });

    });
    //chat
    $('.chat-users li').click(function() {
        var image = $(this).children().children('img').attr('src');
        var name = $(this).children().children('.mx-2').text();

        $('.chat-box .chat-head img').attr('src', image);
        $('.chat-box .chat-head h6').text(name);

    });
    //like-dislike
    $('.like-dislike .like').on('click', function(e) {
        var p_id = $(this).attr('data-id');
        e.preventDefault()
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "user/post/like",
            cache: false,
            data: { 'id': p_id },
            dataType: "json",
            success: function(data) {

                $('.we-video-info ul li .text-danger span').text(data['info']);
            }
        });
    });
    $('.like-dislike .dislike').on('click', function(e) {
        var p_id = $(this).attr('data-id');
        e.preventDefault()
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "user/post/dislike",
            cache: false,
            data: { 'id': p_id },
            dataType: "json",
            success: function(data) {


                $('.we-video-info ul li .text-secondary span').text(data['info']);
            }
        });
    });
    //loadcomment
    $('.coment-area .cho a').on('click', function(e) {
        e.preventDefault();
        var p_id = $(this).attr('data-id');
        var parent1 = $(this).parent('li');
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "user/post/loadComment",
            cache: false,
            data: { 'id': p_id },
            dataType: "json",
            success: function(data) {
                for (let i of data['cmt']) {
                    var comment_HTML = '<li><div class="comet-avatar"><img alt="" src="public/' + i['user_image'] + '"></div><div class="we-comment"><h5><a title="" href="time-line.html">' + i['user_name'] + '</a></h5><p>' + i['content'] + '</p><div class="inline-itms"><span>1 minut ago</span><a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a><a title="" href="#"><i class="fa fa-heart"></i></a></div></div></li>';
                    $(comment_HTML).insertBefore(parent1);
                }
                console.log(data);
            }
        });

        console.log(p_id);
    });
});
