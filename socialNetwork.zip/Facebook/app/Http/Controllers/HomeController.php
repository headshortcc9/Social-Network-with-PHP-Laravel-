<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\user_info;
use App\Models\Post;
use App\Models\post_comment;
use App\Models\relationship;
use App\Models\requestAdd;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $friend_request = array();
        //
        $relationships = relationship::where('user1',Auth::user()->id)->orWhere('user2',Auth::user()->id)->get();

        //
        $tmp = requestAdd::where('receiver_id',Auth::user()->id)->get();
        //
        $u_f_id=array();
        //
        //Friend
        $list_friend=array();
        foreach($relationships as $i){
            if($i->user1==Auth::user()->id){
                $u=User::find($i->user2);
                $list_friend[]=$u;
                $u_f_id[]=$u->id;
            }
            else {
                $u=User::find($i->user1);
                $list_friend[]=$u;
                $u_f_id[]=$u->id;
            }
        }
        $u_f_id[]=Auth::user()->id;
        //
        $post = Post::whereIn('user_id',$u_f_id)->get();
        //request
        foreach($tmp as $i){
            $u = User::find($i->sender_id);
            $arr=[
                'user_img' => $u->user_info->Avatar_pic,
                'user_name' => $u->name,
                'rel_id' => $u->id,
                'res_id'=> $i->id,
                'time' => $i->created_at
            ];
            $friend_request[]=$arr;
        }

        // $name = "Nguyen Xuan Nghia";
        // $data['name']=$name;
        return view('home',compact('post','friend_request','list_friend'));
    }

}
