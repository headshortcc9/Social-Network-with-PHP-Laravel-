<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>NxN System</title>
    <link rel="icon" href="<?php echo e(asset('images/fav1.png')); ?>" type="image/png" sizes="32x32">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/weather-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/toast-notification.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/page-tour.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nxnStyle.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

</head>

<body>
    <div class="wavy-wraper">
        <div class="wavy">
            <span style="--i:1;">p</span>
            <span style="--i:2;">i</span>
            <span style="--i:3;">t</span>
            <span style="--i:4;">n</span>
            <span style="--i:5;">i</span>
            <span style="--i:6;">k</span>
            <span style="--i:7;">.</span>
            <span style="--i:8;">.</span>
            <span style="--i:9;">.</span>
        </div>
    </div>
    <div class="theme-layout">

        <div class="postoverlay"></div>

        <div class="responsive-header">
            <div class="mh-head first Sticky">
                <span class="mh-btns-left">
                    <a class="" href="#menu"><i class="fa fa-align-justify"></i></a>
                </span>
                <span class="mh-text">
                    <a href="newsfeed.html" title=""><img src="<?php echo e(asset('images/logo2.png')); ?>" alt=""></a>
                </span>
                <span class="mh-btns-right">
                    <a class="fa fa-sliders" href="#shoppingbag"></a>
                </span>
            </div>
            <div class="mh-head second">
                <form class="mh-form">
                    <input placeholder="search" />
                    <a href="#/" class="fa fa-search"></a>
                </form>
            </div>
        </div><!-- responsive header -->
        <div class="topbar stick border-bottom border-danger">
            <div class="logo">
                <a title="" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/nxn_system_light.png')); ?>" alt=""></a>
            </div>
            <div class="top-area">
                <div class="main-menu">
                    <span>
                        <i class="fa fa-braille"></i>
                    </span>
                </div>
                <div class="top-search">
                    <form method="post" class="">
                        <input type="text" placeholder="Search People, Pages, Groups etc">
                        <button data-ripple><i class="ti-search"></i></button>
                    </form>
                </div>
                <div class="page-name">
                    <span>Newsfeed</span>
                </div>
                <ul class="setting-area">
                    <li><a href="newsfeed.html" title="Home" data-ripple=""><i class="fa fa-home"></i></a></li>
                    <li>
                        <a href="#" title="Friend Requests" data-ripple="">
                            <i class="fa fa-user"></i><em class="bg-red">5</em>
                        </a>
                        <div class="dropdowns">
                            <span>5 New Requests <a href="#" title="">View all Requests</a></span>
                            <ul class="drops-menu">
                                <li>
                                    <div>
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-2.jpg')); ?>" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">Loren</a></h6>
                                            <span><b>Amy</b> is mutule friend</span>
                                            <i>yesterday</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title=""><i class="fa fa-heart"></i></a>
                                            <a href="#" title=""><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-3.jpg')); ?>" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">Tina Trump</a></h6>
                                            <span><b>Simson</b> is mutule friend</span>
                                            <i>2 days ago</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title=""><i class="fa fa-heart"></i></a>
                                            <a href="#" title=""><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-4.jpg')); ?>" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">Andrew</a></h6>
                                            <span><b>Bikra</b> is mutule friend</span>
                                            <i>4 hours ago</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title=""><i class="fa fa-heart"></i></a>
                                            <a href="#" title=""><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-5.jpg')); ?>" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">Dasha</a></h6>
                                            <span><b>Sarah</b> is mutule friend</span>
                                            <i>9 hours ago</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title=""><i class="fa fa-heart"></i></a>
                                            <a href="#" title=""><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div>
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-1.jpg')); ?>" alt="">
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6><a href="#" title="">Emily</a></h6>
                                            <span><b>Amy</b> is mutule friend</span>
                                            <i>4 hours ago</i>
                                        </div>
                                        <div class="add-del-friends">
                                            <a href="#" title=""><i class="fa fa-heart"></i></a>
                                            <a href="#" title=""><i class="fa fa-trash"></i></a>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <a href="friend-requests.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="Notification" data-ripple="">
                            <i class="fa fa-bell"></i><em class="bg-purple">7</em>
                        </a>
                        <div class="dropdowns">
                            <span>4 New Notifications <a href="#" title="">Mark all as read</a></span>
                            <ul class="drops-menu">
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-1.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>sarah Loren</h6>
                                            <span>commented on your new profile status</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-2.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Jhon doe</h6>
                                            <span>Nicholas Grissom just became friends. Write on his wall.</span>
                                            <i>4 hours ago</i>
                                            <figure>
                                                <span>Today is Marina Valentine’s Birthday! wish for celebrating</span>
                                                <img src="<?php echo e(asset('images/birthday.png')); ?>" alt="">
                                            </figure>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-3.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Andrew</h6>
                                            <span>commented on your photo.</span>
                                            <i>Sunday</i>
                                            <figure>
                                                <span>"Celebrity looks Beautiful in that outfit! We should see each"</span>
                                                <img src="<?php echo e(asset('images/resources/admin.jpg')); ?>" alt="">
                                            </figure>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-4.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Tom cruse</h6>
                                            <span>nvited you to attend to his event Goo in</span>
                                            <i>May 19</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                                <li>
                                    <a href="notifications.html" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-5.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Amy</h6>
                                            <span>Andrew Changed his profile picture. </span>
                                            <i>dec 18</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                            </ul>
                            <a href="notifications.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li>
                        <a href="#" title="Messages" data-ripple=""><i class="fa fa-commenting"></i><em class="bg-blue">9</em></a>
                        <div class="dropdowns">
                            <span>5 New Messages <a href="#" title="">Mark all as read</a></span>
                            <ul class="drops-menu">
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-1.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>sarah Loren</h6>
                                            <span><i class="ti-check"></i> Hi, how r u dear ...?</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-2.jpg')); ?>" alt="">
                                            <span class="status f-offline"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Jhon doe</h6>
                                            <span><i class="ti-check"></i> We’ll have to check that at the office and see if the client is on board with</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-3.jpg')); ?>" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Andrew</h6>
                                            <span> <i class="fa fa-paperclip"></i>Hi Jack's! It’s Diana, I just wanted to let you know that we have to reschedule..</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-4.jpg')); ?>" alt="">
                                            <span class="status f-offline"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Tom cruse</h6>
                                            <span><i class="ti-check"></i> Great, I’ll see you tomorrow!.</span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                                <li>
                                    <a class="show-mesg" href="#" title="">
                                        <figure>
                                            <img src="<?php echo e(asset('images/resources/thumb-5.jpg')); ?>" alt="">
                                            <span class="status f-away"></span>
                                        </figure>
                                        <div class="mesg-meta">
                                            <h6>Amy</h6>
                                            <span><i class="fa fa-paperclip"></i> Sed ut perspiciatis unde omnis iste natus error sit </span>
                                            <i>2 min ago</i>
                                        </div>
                                    </a>
                                    <span class="tag">New</span>
                                </li>
                            </ul>
                            <a href="chat-messenger.html" title="" class="more-mesg">View All</a>
                        </div>
                    </li>
                    <li><a href="#" title="Languages" data-ripple=""><i class="fa fa-globe"></i><em>EN</em></a>
                        <div class="dropdowns languages">
                            <div data-gutter="10" class="row">
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/UK.png')); ?>">English(UK)
                                            </a>
                                        </li>
                                        <li class="active">
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/US.png')); ?>">English(US)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/DE.png')); ?>">Deutsch
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/NED.png')); ?>">Nederlands
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/FR.png')); ?>">Français
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/SP.png')); ?>">Español
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/ARG.png')); ?>">Español (AR)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/IT.png')); ?>">Italiano
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/PT.png')); ?>">Português (PT)
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/BR.png')); ?>">Português (BR)
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/FIN.png')); ?>">Suomi
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/SW.png')); ?>">Svenska
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/DEN.png')); ?>">Dansk
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/CZ.png')); ?>">Čeština
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/HUN.png')); ?>">Magyar
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/ROM.png')); ?>">Română
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/JP.png')); ?>">日本語
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/CN.png')); ?>">简体中文
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/PL.png')); ?>">Polski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/GR.png')); ?>">Ελληνικά
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/TUR.png')); ?>">Türkçe
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/BUL.png')); ?>">Български
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/ARB.png')); ?>">العربية
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/KOR.png')); ?>">한국어
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/ISR.png')); ?>">עברית
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/LAT.png')); ?>">Latviski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/UKR.png')); ?>">Українська
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/IND.png')); ?>">Bahasa Indonesia
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/MAL.png')); ?>">Bahasa Malaysia
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/TAI.png')); ?>">ภาษาไทย
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div class="col-md-3">
                                    <ul class="dropdown-meganav-select-list-lang">
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/CRO.png')); ?>">Hrvatski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/LIT.png')); ?>">Lietuvių
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/SLO.png')); ?>">Slovenčina
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/SERB.png')); ?>">Srpski
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/SLOVE.png')); ?>">Slovenščina
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/NAM.png')); ?>">Tiếng Việt
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/PHI.png')); ?>">Filipino
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/ICE.png')); ?>">Íslenska
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/EST.png')); ?>">Eesti
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <img title="Image Title" alt="Image Alternative text" src="<?php echo e(asset('images/flags/RU.png')); ?>">Русский
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a href="#" title="Help" data-ripple=""><i class="fa fa-question-circle"></i></a>
                        <div class="dropdowns helps">
                            <span>Quick Help</span>
                            <form method="post">
                                <input type="text" placeholder="How can we help you?">
                            </form>
                            <span>Help with this page</span>
                            <ul class="help-drop">
                                <li><a href="forum.html" title=""><i class="fa fa-book"></i>Community & Forum</a></li>
                                <li><a href="faq.html" title=""><i class="fa fa-question-circle-o"></i>FAQs</a></li>
                                <li><a href="career.html" title=""><i class="fa fa-building-o"></i>Carrers</a></li>
                                <li><a href="privacy.html" title=""><i class="fa fa-pencil-square-o"></i>Terms & Policy</a></li>
                                <li><a href="#" title=""><i class="fa fa-map-marker"></i>Contact</a></li>
                                <li><a href="#" title=""><i class="fa fa-exclamation-triangle"></i>Report a Problem</a></li>
                            </ul>
                        </div>
                    </li>
                </ul>
                <div class="user-img">
                    <h5><?php echo (Auth::user()->name); ?></h5>
                    <img class='img-fluid avatar_img' src="<?php echo e(asset(Auth::user()->user_info->Avatar_pic)); ?>" alt="">
                    <span class="status f-online"></span>
                    <div class="user-setting">
                        <span class="seting-title">Chat setting <a href="#" title="">see all</a></span>
                        <ul class="chat-setting">
                            <li><a href="#" title=""><span class="status f-online"></span>online</a></li>
                            <li><a href="#" title=""><span class="status f-away"></span>away</a></li>
                            <li><a href="#" title=""><span class="status f-off"></span>offline</a></li>
                        </ul>
                        <span class="seting-title">User setting <a href="#" title="">see all</a></span>
                        <ul class="log-out">
                            <li><a href="<?php echo e(url('user/about')); ?>" title=""><i class="ti-user"></i> view profile</a></li>
                            <li><a href="<?php echo e(url('user/setting')); ?>" title=""><i class="ti-pencil-alt"></i>edit profile</a></li>
                            <li><a href="#" title=""><i class="ti-target"></i>activity log</a></li>
                            <li>
                                <!-- <a href="logout.html" title=""><i class="ti-power-off"></i>log out</a> -->
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">

                                    <i class="ti-power-off"></i>log out</a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
                <span class="px-2"> <a href="chat-msg"><i class='fa fa-facebook-f'></i></a></span>
                <span class="ti-settings main-menu" data-ripple=""></span>
            </div>
            <nav>
                <ul class="nav-list">
                    <h3>Function coming soon</h3>
                </ul>

            </nav><!-- nav menu -->
        </div><!-- topbar -->
        <section>
            <div class="gap2 gray-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row merged20" id="page-contents">
                                <div class="user-profile">
                                    <figure>

                                        <img class='cover_img' src="<?php echo e(asset($info->user_info->Cover_pic)); ?>" alt="">
                                        <ul class="profile-controls">
                                            <?php if($is_friend==0): ?>
                                            <li><a href="#" id='btn-add-friend' title="Add friend" data-toggle="tooltip"><i class="fa fa-user-plus"></i></a></li>
                                            <form id='addFriend' action="" method="post" class="d-none">
                                                <input type="hidden" name='user_id' value=<?php echo e($info->id); ?> data-url='<?php echo e(route('sendRequest')); ?>'>
                                            </form>
                                            <?php else: ?>
                                            <li><a href="#" id='btn-un-friend' title="Unfriend" data-toggle="tooltip"><i class='fa fa-user-times'></i></a></li>
                                            <form id='unFriend' action="" method="post" class="d-none">
                                                <input type="hidden" name='user_id' value=<?php echo e($info->id); ?> data-url='<?php echo e(route('unfriend')); ?>'>
                                            </form>
                                            <?php endif; ?>
                                            <li><a href="#" title="Follow" data-toggle="tooltip"><i class="fa fa-star"></i></a></li>
                                            <li><a class="send-mesg" href="#" title="Send Message" data-toggle="tooltip"><i class="fa fa-comment"></i></a></li>
                                            <li>
                                                <div class="edit-seting" title="Edit Profile image"><i class="fa fa-sliders"></i>
                                                    <ul class="more-dropdown">
                                                        <li><a href="setting.html" title="">Update Profile Photo</a></li>
                                                        <li><a href="setting.html" title="">Update Header Photo</a></li>
                                                        <li><a href="setting.html" title="">Account Settings</a></li>
                                                        <li><a href="support-and-help.html" title="">Find Support</a></li>
                                                        <li><a class="bad-report" href="#" title="">Report Profile</a></li>
                                                        <li><a href="#" title="">Block Profile</a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>

                                    </figure>

                                    <div class="profile-section">
                                        <div class="row">
                                            <div class="col-lg-2 col-md-3">
                                                <div class="profile-author">
                                                    <div class="profile-author-thumb">
                                                        <img id='avatar-profile' class='avatar_img_x img-fluid' alt="author" src="<?php echo e(asset($info->user_info->Avatar_pic)); ?>">
                                                        <div class="edit-dp">
                                                            <label class="fileContainer">
                                                                <i class="fa fa-camera"></i>
                                                                <form id='change-avatar-pic' action="" method="post" enctype="multipart/form-data">
                                                                    <input type="file" data-url='<?php echo e(route('setting')); ?>' name='avatar_pic'>
                                                                    <input type="hidden" name='function' value="change-avatar-pic">
                                                                </form>
                                                            </label>
                                                        </div>
                                                    </div>

                                                    <div class="author-content">
                                                        <a class="h3 author-name" href="about.html"><?php echo e($info->name); ?></a>
                                                        <div class="country"><?php echo e($info->user_info->Country); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-10 col-md-9">
                                                <ul class="profile-menu">
                                                    <li>
                                                        <a class="<?php if(url()->current()==url('user/about')) echo 'active'; ?>" href="<?php echo e(url('user/about')); ?>">About</a>
                                                    </li>
                                                </ul>
                                                <ol class="folw-detail">
                                                    <li><span>Posts</span><ins>101</ins></li>
                                                    <li><span>Followers</span><ins>1.3K</ins></li>
                                                    <li><span>Following</span><ins>22</ins></li>
                                                </ol>
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- user profile banner  -->
                                <div class="col-lg-4 col-md-4">
                                    <aside class="sidebar">
                                        <div class="central-meta stick-widget">
                                            <span class="create-post">Personal Info</span>
                                            <div class="personal-head">
                                                <span class="f-title"><i class="fa fa-user"></i> About Me:</span>
                                                <p>
                                                    <?php echo e($info->user_info->About); ?>

                                                </p>
                                                <span class="f-title"><i class="fa fa-birthday-cake"></i> Birthday:</span>
                                                <p>
                                                    <?php echo e($info->user_info->Birthday_Date); ?>

                                                </p>
                                                <span class="f-title"><i class="fa fa-phone"></i> Phone Number:</span>
                                                <p>
                                                    <?php echo e($info->user_info->phone_number); ?>

                                                </p>

                                                <span class="f-title"><i class="fa fa-male"></i> Gender:</span>
                                                <p>
                                                    <?php echo e($info->user_info->Gender); ?>

                                                </p>
                                                <span class="f-title"><i class="fa fa-globe"></i> Country:</span>
                                                <p>
                                                    <?php echo e($info->user_info->Country); ?>

                                                </p>
                                                <span class="f-title"><i class="fa fa-briefcase"></i> Occupation:</span>
                                                <p>
                                                    <?php echo e($info->user_info->job); ?>

                                                </p>
                                                <span class="f-title"><i class="fa fa-handshake-o"></i> Joined:</span>
                                                <p>
                                                    <?php echo e($info->created_at); ?>

                                                </p>

                                                <span class="f-title"><i class="fa fa-envelope"></i> Email & Website:</span>
                                                <p>
                                                    <?php echo e($info->email); ?>

                                                </p>

                                            </div>
                                        </div>
                                    </aside>
                                </div>
                                <div class="col-lg-8 col-md-8">
                                    <div class="central-meta">
                                        <span class="create-post">General Info<a href="#" title="">See All</a></span>
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="gen-metabox">
                                                    <span><i class="fa fa-puzzle-piece"></i> Hobbies</span>
                                                    <p>
                                                        <?php echo e($info->user_info->Hobbies); ?>

                                                    </p>
                                                </div>
                                                <div class="gen-metabox">
                                                    <span><i class="fa fa-plus"></i> Others Interests</span>
                                                    <p>
                                                        Swimming, Surfing, Uber Diving, Anime, Photography, Tattoos, Street Art.
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="gen-metabox">
                                                    <span><i class="fa fa-mortar-board"></i> Education</span>
                                                    <p>
                                                        <?php echo e($info->user_info->Education); ?>

                                                    </p>
                                                </div>
                                                <div class="gen-metabox">
                                                    <span><i class="fa fa-certificate"></i> Work and experience</span>
                                                    <p>
                                                        <?php echo e($info->user_info->job); ?>

                                                    </p>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="gen-metabox no-margin">
                                                    <span><i class="fa fa-sitemap"></i> Social Networks</span>
                                                    <ul class="sociaz-media">
                                                        <li><a class="facebook" href="#" title=""><i class="fa fa-facebook"></i></a></li>
                                                        <li><a class="twitter" href="#" title=""><i class="fa fa-twitter"></i></a></li>
                                                        <li><a class="google" href="#" title=""><i class="fa fa-google-plus"></i></a></li>
                                                        <li><a class="vk" href="#" title=""><i class="fa fa-vk"></i></a></li>
                                                        <li><a class="instagram" href="#" title=""><i class="fa fa-instagram"></i></a></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="gen-metabox no-margin">
                                                    <span><i class="fa fa-trophy"></i> Badges</span>
                                                    <ul class="badged">
                                                        <li><img src="<?php echo e(asset('images/badges/tt7.png')); ?>" alt=""></li>
                                                        <li><img src="<?php echo e(asset('images/badges/tt6.png')); ?>" alt=""></li>
                                                        <li><img src="<?php echo e(asset('images/badges/badge21.png')); ?>" alt=""></li>
                                                        <li><img src="<?php echo e(asset('images/badges/badge3.png')); ?>" alt=""></li>
                                                        <li><img src="<?php echo e(asset('images/badges/badge4.png')); ?>" alt=""></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- General infomations -->

                                    <div class="central-meta">
                                        <span class="create-post">Friend's (1) <a href="timeline-friends2.html" title="">See All</a></span>
                                        <ul class="frndz-list">
                                            <li>
                                                <img src="<?php echo e(asset('images/resources/recent1.jpg')); ?>" alt="">
                                                <div class="sugtd-frnd-meta">
                                                    <a href="#" title="">Olivia</a>
                                                    <span>1 mutual friend</span>
                                                    <ul class="add-remove-frnd">
                                                        <li class="add-tofrndlist"><a class="send-mesg" href="#" title="Send Message"><i class="fa fa-commenting"></i></a></li>
                                                        <li class="remove-frnd"><a href="#" title="remove friend"><i class="fa fa-user-times"></i></a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                    </div><!-- friends list -->
                                    <div class="central-meta">
                                        <span class="create-post">Photos (1) <a href="timeline-photos.html" title="">See All</a></span>
                                        <ul class="photos-list">
                                            <li>
                                                <div class="item-box">
                                                    <a class="strip" href="<?php echo e(asset('images/resources/photo-22.jpg')); ?>" title="" data-strip-group="mygroup" data-strip-group-options="loop: false">
                                                        <img src="<?php echo e(asset('images/resources/photo2.jpg')); ?>" alt=""></a>
                                                    <div class="over-photo">
                                                        <div class="likes heart" title="Like/Dislike">❤ <span>15</span></div>
                                                        <span>20 hours ago</span>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div><!-- Photos -->
                                    <div class="central-meta">
                                        <span class="create-post">Videos (33) <a href="timeline-videos.html" title="">See All</a></span>
                                        <ul class="videos-list">
                                            <li>
                                                <div class="item-box">
                                                    <a href="https://www.youtube.com/watch?v=fF382gwEnG8&amp;t=1s" title="" data-strip-group="mygroup" class="strip" data-strip-options="width: 700,height: 450,youtube: { autoplay: 1 }"><img src="<?php echo e(asset('images/resources/vid-11.jpg')); ?>" alt="">
                                                        <i>
                                                            <svg version="1.1" class="play" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="50px" width="50px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
                                                                <path class="stroke-solid" fill="none" stroke="" d="M49.9,2.5C23.6,2.8,2.1,24.4,2.5,50.4C2.9,76.5,24.7,98,50.3,97.5c26.4-0.6,47.4-21.8,47.2-47.7
													C97.3,23.7,75.7,2.3,49.9,2.5" />
                                                                <path class="icon" fill="" d="M38,69c-1,0.5-1.8,0-1.8-1.1V32.1c0-1.1,0.8-1.6,1.8-1.1l34,18c1,0.5,1,1.4,0,1.9L38,69z" />
                                                            </svg>
                                                        </i>
                                                    </a>
                                                    <div class="over-photo">
                                                        <div class="likes heart" title="Like/Dislike">❤ <span>15</span></div>
                                                        <span>20 hours ago</span>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div><!-- Videos -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- content -->




        <!-- left sidebar menu -->
        <div class="bottombar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <span class="copyright">© Pitnik 2020. All rights reserved.</span>
                        <i><img src="<?php echo e(asset('images/credit-cards.png')); ?>" alt=""></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="side-panel">
        <h4 class="panel-title">General Setting</h4>
        <form method="post">
            <div class="setting-row">
                <span>use night mode</span>
                <input type="checkbox" id="nightmode1" />
                <label for="nightmode1" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Notifications</span>
                <input type="checkbox" id="switch22" />
                <label for="switch22" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Notification sound</span>
                <input type="checkbox" id="switch33" />
                <label for="switch33" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>My profile</span>
                <input type="checkbox" id="switch44" />
                <label for="switch44" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Show profile</span>
                <input type="checkbox" id="switch55" />
                <label for="switch55" data-on-label="ON" data-off-label="OFF"></label>
            </div>
        </form>
        <h4 class="panel-title">Account Setting</h4>
        <form method="post">
            <div class="setting-row">
                <span>Sub users</span>
                <input type="checkbox" id="switch66" />
                <label for="switch66" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>personal account</span>
                <input type="checkbox" id="switch77" />
                <label for="switch77" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Business account</span>
                <input type="checkbox" id="switch88" />
                <label for="switch88" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Show me online</span>
                <input type="checkbox" id="switch99" />
                <label for="switch99" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Delete history</span>
                <input type="checkbox" id="switch101" />
                <label for="switch101" data-on-label="ON" data-off-label="OFF"></label>
            </div>
            <div class="setting-row">
                <span>Expose author name</span>
                <input type="checkbox" id="switch111" />
                <label for="switch111" data-on-label="ON" data-off-label="OFF"></label>
            </div>
        </form>
    </div><!-- side panel -->

    <div class="popup-wraper2">
        <div class="popup post-sharing">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <select data-placeholder="Share to friends..." multiple class="chosen-select multi">
                        <option>Share in your feed</option>
                        <option>Share in friend feed</option>
                        <option>Share in a page</option>
                        <option>Share in a group</option>
                        <option>Share in message</option>
                    </select>
                    <div class="post-status">
                        <span><i class="fa fa-globe"></i></span>
                        <ul>
                            <li><a href="#" title=""><i class="fa fa-globe"></i> Post Globaly</a></li>
                            <li><a href="#" title=""><i class="fa fa-user"></i> Post Private</a></li>
                            <li><a href="#" title=""><i class="fa fa-user-plus"></i> Post Friends</a></li>
                        </ul>
                    </div>
                </div>
                <div class="postbox">
                    <div class="post-comt-box">
                        <form method="post">
                            <input type="text" placeholder="Search Friends, Pages, Groups, etc....">
                            <textarea placeholder="Say something about this..."></textarea>
                            <div class="add-smiles">
                                <span title="add icon" class="em em-expressionless"></span>
                                <div class="smiles-bunch">
                                    <i class="em em---1"></i>
                                    <i class="em em-smiley"></i>
                                    <i class="em em-anguished"></i>
                                    <i class="em em-laughing"></i>
                                    <i class="em em-angry"></i>
                                    <i class="em em-astonished"></i>
                                    <i class="em em-blush"></i>
                                    <i class="em em-disappointed"></i>
                                    <i class="em em-worried"></i>
                                    <i class="em em-kissing_heart"></i>
                                    <i class="em em-rage"></i>
                                    <i class="em em-stuck_out_tongue"></i>
                                </div>
                            </div>

                            <button type="submit"></button>
                        </form>
                    </div>
                    <figure><img src="<?php echo e(asset('images/resources/share-post.jpg')); ?>" alt=""></figure>
                    <div class="friend-info">
                        <figure>
                            <img alt="" src="<?php echo e(asset('images/resources/admin.jpg')); ?>">
                        </figure>
                        <div class="friend-name">
                            <ins><a title="" href="time-line.html">Jack Carter</a> share <a title="" href="#">link</a></ins>
                            <span>Yesterday with @Jack  Piller and @Emily  Stone at the concert of # Rock'n'Rolla in Ontario.</span>
                        </div>
                    </div>
                    <div class="share-to-other">
                        <span>Share to other socials</span>
                        <ul>
                            <li><a class="facebook-color" href="#" title=""><i class="fa fa-facebook-square"></i></a></li>
                            <li><a class="twitter-color" href="#" title=""><i class="fa fa-twitter-square"></i></a></li>
                            <li><a class="dribble-color" href="#" title=""><i class="fa fa-dribbble"></i></a></li>
                            <li><a class="instagram-color" href="#" title=""><i class="fa fa-instagram"></i></a></li>
                            <li><a class="pinterest-color" href="#" title=""><i class="fa fa-pinterest-square"></i></a></li>
                        </ul>
                    </div>
                    <div class="copy-email">
                        <span>Copy & Email</span>
                        <ul>
                            <li><a href="#" title="Copy Post Link"><i class="fa fa-link"></i></a></li>
                            <li><a href="#" title="Email this Post"><i class="fa fa-envelope"></i></a></li>
                        </ul>
                    </div>
                    <div class="we-video-info">
                        <ul>
                            <li>
                                <span title="" data-toggle="tooltip" class="views" data-original-title="views">
                                    <i class="fa fa-eye"></i>
                                    <ins>1.2k</ins>
                                </span>
                            </li>
                            <li>
                                <span title="" data-toggle="tooltip" class="views" data-original-title="views">
                                    <i class="fa fa-share-alt"></i>
                                    <ins>20k</ins>
                                </span>
                            </li>
                        </ul>
                        <button class="main-btn color" data-ripple="">Submit</button>
                        <button class="main-btn cancel" data-ripple="">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- share popup -->

    <div class="popup-wraper3">
        <div class="popup">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <h5>Report Post</h5>
                </div>
                <div class="Rpt-meta">
                    <span>We're sorry something's wrong. How can we help?</span>
                    <form method="post" class="c-form">
                        <div class="form-radio">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio" checked="checked"><i class="check-box"></i>It's spam or abuse
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>It breaks r/technology's rules
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>Not Related
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="radio"><i class="check-box"></i>Other issues
                                </label>
                            </div>
                        </div>
                        <div>
                            <label>Write about Report</label>
                            <textarea placeholder="write someting about Post" rows="2"></textarea>
                        </div>
                        <div>
                            <button data-ripple="" type="submit" class="main-btn">Submit</button>
                            <a href="#" data-ripple="" class="main-btn3 cancel">Close</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- report popup -->

    <div class="popup-wraper1">
        <div class="popup direct-mesg">
            <span class="popup-closed"><i class="ti-close"></i></span>
            <div class="popup-meta">
                <div class="popup-head">
                    <h5>Send Message</h5>
                </div>
                <div class="send-message">
                    <form method="post" class="c-form">
                        <input type="text" placeholder="Sophia">
                        <textarea placeholder="Write Message"></textarea>
                        <button type="submit" class="main-btn">Send</button>
                    </form>
                    <div class="add-smiles">
                        <div class="uploadimage">
                            <i class="fa fa-image"></i>
                            <label class="fileContainer">
                                <input type="file">
                            </label>
                        </div>
                        <span title="add icon" class="em em-expressionless"></span>
                        <div class="smiles-bunch">
                            <i class="em em---1"></i>
                            <i class="em em-smiley"></i>
                            <i class="em em-anguished"></i>
                            <i class="em em-laughing"></i>
                            <i class="em em-angry"></i>
                            <i class="em em-astonished"></i>
                            <i class="em em-blush"></i>
                            <i class="em em-disappointed"></i>
                            <i class="em em-worried"></i>
                            <i class="em em-kissing_heart"></i>
                            <i class="em em-rage"></i>
                            <i class="em em-stuck_out_tongue"></i>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div><!-- send message popup -->

    <div class="modal fade" id="img-comt">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="pop-image">
                                <div class="pop-item">
                                    <figure><img src="<?php echo e(asset('images/resources/blog-detail.jpg')); ?>" alt=""></figure>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="user">
                                <figure><img src="<?php echo e(asset('images/resources/user1.jpg')); ?>" alt=""></figure>
                                <div class="user-information">
                                    <h4><a href="#" title="">Danile Walker</a></h4>
                                    <span>2 hours ago</span>
                                </div>
                                <a href="#" title="Follow" data-ripple="">Follow</a>
                            </div>
                            <div class="we-video-info">
                                <ul>
                                    <li>
                                        <div title="Like/Dislike" class="likes heart">❤ <span>2K</span></div>
                                    </li>
                                    <li>
                                        <span title="Comments" class="comment">
                                            <i class="fa fa-commenting"></i>
                                            <ins>52</ins>
                                        </span>
                                    </li>

                                    <li>
                                        <span>
                                            <a title="Share" href="#" class="">
                                                <i class="fa fa-share-alt"></i>
                                            </a>
                                            <ins>20</ins>
                                        </span>
                                    </li>
                                </ul>
                                <div class="users-thumb-list">
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Anderw">
                                        <img src="<?php echo e(asset('images/resources/userlist-1.jpg')); ?>" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="frank">
                                        <img src="<?php echo e(asset('images/resources/userlist-2.jpg')); ?>" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Sara">
                                        <img src="<?php echo e(asset('images/resources/userlist-3.jpg')); ?>" alt="">
                                    </a>
                                    <a href="#" title="" data-toggle="tooltip" data-original-title="Amy">
                                        <img src="<?php echo e(asset('images/resources/userlist-4.jpg')); ?>" alt="">
                                    </a>
                                    <span><strong>You</strong>, <b>Sarah</b> and <a title="" href="#">24+ more</a> liked</span>
                                </div>
                            </div>
                            <div style="display: block;" class="coment-area">
                                <ul class="we-comet">
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="<?php echo e(asset('images/resources/nearly3.jpg')); ?>">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Jason borne</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster. please vote this video and like our channel</p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>

                                    </li>
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="<?php echo e(asset('images/resources/comet-4.jpg')); ?>">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Sophia</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster.
                                                <i class="em em-smiley"></i>
                                            </p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="comet-avatar">
                                            <img alt="" src="<?php echo e(asset('images/resources/comet-4.jpg')); ?>">
                                        </div>
                                        <div class="we-comment">
                                            <h5><a title="" href="time-line.html">Sophia</a></h5>
                                            <p>we are working for the dance and sing songs. this video is very awesome for the youngster.
                                                <i class="em em-smiley"></i>
                                            </p>
                                            <div class="inline-itms">
                                                <span>1 year ago</span>
                                                <a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
                                                <a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <a class="showmore underline" title="" href="#">more comments+</a>
                                    </li>
                                    <li class="post-comment">
                                        <div class="comet-avatar">
                                            <img alt="" src="<?php echo e(asset('images/resources/nearly1.jpg')); ?>">
                                        </div>
                                        <div class="post-comt-box">
                                            <form method="post">
                                                <textarea placeholder="Post your comment"></textarea>
                                                <div class="add-smiles">
                                                    <div class="uploadimage">
                                                        <i class="fa fa-image"></i>
                                                        <label class="fileContainer">
                                                            <input type="file">
                                                        </label>
                                                    </div>
                                                    <span title="add icon" class="em em-expressionless"></span>
                                                    <div class="smiles-bunch">
                                                        <i class="em em---1"></i>
                                                        <i class="em em-smiley"></i>
                                                        <i class="em em-anguished"></i>
                                                        <i class="em em-laughing"></i>
                                                        <i class="em em-angry"></i>
                                                        <i class="em em-astonished"></i>
                                                        <i class="em em-blush"></i>
                                                        <i class="em em-disappointed"></i>
                                                        <i class="em em-worried"></i>
                                                        <i class="em em-kissing_heart"></i>
                                                        <i class="em em-rage"></i>
                                                        <i class="em em-stuck_out_tongue"></i>
                                                    </div>
                                                </div>

                                                <button type="submit"></button>
                                            </form>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- The Scrolling Modal image with comment -->

    <script src="<?php echo e(asset('js/main.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/toast-notificatons.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page-tourintro.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page-tour-init.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/profile.js')); ?>"></script>
</body>


</html>
<?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/users/profile.blade.php ENDPATH**/ ?>