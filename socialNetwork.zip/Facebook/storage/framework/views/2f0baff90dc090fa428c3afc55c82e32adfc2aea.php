<!DOCTYPE html>
<html lang="en">


<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
	<title>NxN System</title>
    <link rel="icon" href="<?php echo e(asset('images/fav1.png')); ?>" type="image/png" sizes="32x32">

    <link rel="stylesheet" href="<?php echo e(asset('css/main.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/weather-icon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/weather-icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/color.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
</head>
<body>
<div class="gap no-gap signin whitish medium-opacity">
    <div class="bg-image" style="background-image:url(public/images/resources/theme-bg.jpg)"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="big-Ad">
                    <figure><img src="<?php echo e(asset('images/nxn_system (1).png')); ?>" alt=""></figure>
                    <h1>Welcome to NxN System</h1>
                    <p>
                        NxN is a social network that can be used to connect people. use this for multipurpose social activities like job, dating, posting, bloging and much more. Now join & Make Cool Friends around the world !!!
                    </p>

                    <div class="fun-fact">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-4">
                                <div class="fun-box">
                                    <i class="ti-check-box"></i>
                                    <h6>Registered People</h6>
                                    <span>1,01,242</span>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-4">
                                <div class="fun-box">
                                    <i class="ti-layout-media-overlay-alt-2"></i>
                                    <h6>Posts Published</h6>
                                    <span>21,03,245</span>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-4">
                                <div class="fun-box">
                                    <i class="ti-user"></i>
                                    <h6>Online Users</h6>
                                    <span>40,145</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-4">
                <?php echo $__env->yieldContent('content'); ?>
            </div>

        </div>
    </div>
</div>

    	<script src="<?php echo e(asset('js/main.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/layouts/temp1.blade.php ENDPATH**/ ?>