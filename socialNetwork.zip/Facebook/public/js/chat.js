function Chat() {
    state = 0;
    rel_id = 0;
    //get state of chat
    this.get_state = function(id) {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "user/get_state",
            type: "POST",
            cache: false,
            data: {
                'partner_id': id
            },
            dataType: "json",
            success: function(data) {
                $('#form_chat input[type=hidden]').val(data['rel_id']);
                rel_id = data['rel_id'];
                update();
            }
        });
    };
    //update
    this.update = update;
}


function update() {
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "user/update_chat",
        type: "POST",
        cache: false,
        data: {
            'rel_id': rel_id,
            'state': state
        },
        dataType: "json",
        success: function(data) {
            var str = " ";
            if (data['change'] == true) {
                data['lines'].forEach(i => {
                    if (i['who'] == 'me') {
                        str += "<li class='me'>" +
                            " <div class='w-75 d-inline-block'>" +
                            " <span class='chat-message-item text-left'>" + i['text'] +
                            "</span>" +
                            " <img src='";
                        if (i['image'] != null) str += i['image'];
                        str += "'>" +
                            "<span class='notification-date'><time class='entry-date updated'>" + i['time'] + "</time></span>" +
                            "</div>" +
                            "</li>"

                    } else {
                        str += "<li class='you'>" +
                            " <div class='row'>" +
                            " <div class='col-md-2 py-2 pl-0 pr-2 text-right'>" +
                            " <img class='w-75 rounded-circle' src='public/" + i['user_img'] + "'>" +
                            "</div>" +
                            "<div class='col-md-8 p-0'>" +
                            " <span class='chat-message-item'>" + i['text'] +
                            "</span>" +
                            " <img src='";
                        if (i['image'] != null) str += i['image'];
                        str += "'>" +
                            "<span class='notification-date'><time class='entry-date updated'>" + i['time'] + "</time></span>" +
                            "</div>" +
                            "<div class='col-md-2'></div>" +
                            "</div>"
                    }
                    $('.chat-list1 ul').append(str);
                    str = " ";
                    document.getElementById("chat-1").scrollTop = document.getElementById("chat-wrap").scrollHeight;
                });

                state = data['state'];
            }
            instance = false;
            console.log(data);
        }
    });
    setTimeout(update, 1500);
}
$(document).ready(function() {
    $('.chat-users li').click(function() {
        var chat = new Chat();
        var partner_id = $(this).children().children('input').val();
        $('.chat-list1 ul').empty();
        chat.get_state(partner_id);
    });

    //setInterval(chat.update, 1000);
    $('#sendie').keydown(function() {
        var key = event.which;
        $("#sendie").css("background-color", "yellow");
    });
    $('#sendie').keyup(function(e) {
        e.preventDefault();
        var key = event.which;
        if (key == 13) {
            $('#form_chat').submit();
            $('#sendie').val(" ");
            document.getElementById("chat_img").value = "";

        }
        $("#sendie").css("background-color", "pink");
    });
    $('#form_chat').submit(function(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "user/send_chat",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                update();
                console.log(data);
            }
        });
    });
    //mail
    $('.chat-users li a').on('click', function(e) {
        e.preventDefault();

        var u_id = $(this).parent().children('input[name=partner_id]').val();
        var u_email = $(this).parent().children('input[name=partner_email]').val();
        $('#u-mail-area form h6').text("To: " + u_email);
        $('#u-mail-area form input[type=hidden]').val(u_id);
        $('#u-mail-area').show();
    });
    $('.chat-users li a').hover(function() {
        $(this).css("color", "red");
    });
    $('.chat-users li a').mouseleave(function() {
        $(this).css("color", "black");
    });
    (function() {
        $(this).css("color", "red");
    });
    $('#u-mail-area .header a').on('click', function(e) {
        e.preventDefault();
        $('#u-mail-area').hide();
    });
    $('#u-mail-area form').submit(function(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "user/send_email",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                $('#u-mail-area').hide();
                $('#u-mail-area form input[type=file]').value = "";
                $('#u-mail-area form textarea').val(" ");
                $('#u-mail-area form input[name=header]').val(" ");
                alert("Your email has been send");
                console.log(data);
            }
        });
    });
});
