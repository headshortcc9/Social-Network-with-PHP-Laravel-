@extends('layouts.user_info')

@section('sub_content')
<div class="col-lg-2 col-md-2">
    <aside class="sidebar">
        <div class="central-meta stick-widget">
            <span class="create-post">Personal Info</span>
            <div class="personal-head">
                <span class="f-title"><i class="fa fa-user"></i> About Me:</span>
                <p>
                    {{Auth::user()->user_info->About}}
                </p>
                <span class="f-title"><i class="fa fa-birthday-cake"></i> Birthday:</span>
                <p>
                    {{Auth::user()->user_info->Birthday_Date}}
                </p>
                <span class="f-title"><i class="fa fa-phone"></i> Phone Number:</span>
                <p>
                    {{Auth::user()->user_info->phone_number}}
                </p>

                <span class="f-title"><i class="fa fa-male"></i> Gender:</span>
                <p>
                    {{Auth::user()->user_info->Gender}}
                </p>
                <span class="f-title"><i class="fa fa-globe"></i> Country:</span>
                <p>
                    {{Auth::user()->user_info->Country}}
                </p>
                <span class="f-title"><i class="fa fa-briefcase"></i> Occupation:</span>
                <p>
                    {{Auth::user()->user_info->job}}
                </p>
                <span class="f-title"><i class="fa fa-handshake-o"></i> Joined:</span>
                <p>
                    {{Auth::user()->created_at}}
                </p>

                <span class="f-title"><i class="fa fa-envelope"></i> Email & Website:</span>
                <p>
                    {{Auth::user()->email}}
                </p>

            </div>
        </div>
    </aside>
</div>
<div class="col-lg-10 col-md-10">
    <div class="central-meta">
        <span class="create-post">General Info<a href="#" title="">See All</a></span>
        <div class="row">
            <div class="col-lg-6">
                <div class="gen-metabox">
                    <span><i class="fa fa-puzzle-piece"></i> Hobbies</span>
                    <p>
                        {{Auth::user()->user_info->Hobbies}}
                    </p>
                </div>
                <div class="gen-metabox">
                    <span><i class="fa fa-plus"></i> Others Interests</span>
                    <p>
                        Swimming, Surfing, Uber Diving, Anime, Photography, Tattoos, Street Art.
                    </p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="gen-metabox">
                    <span><i class="fa fa-mortar-board"></i> Education</span>
                    <p>
                        {{Auth::user()->user_info->Education}}
                    </p>
                </div>
                <div class="gen-metabox">
                    <span><i class="fa fa-certificate"></i> Work and experience</span>
                    <p>
                        {{Auth::user()->user_info->job}}
                    </p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="gen-metabox no-margin">
                    <span><i class="fa fa-sitemap"></i> Social Networks</span>
                    <ul class="sociaz-media">
                        <li><a class="facebook" href="#" title=""><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twitter" href="#" title=""><i class="fa fa-twitter"></i></a></li>
                        <li><a class="google" href="#" title=""><i class="fa fa-google-plus"></i></a></li>
                        <li><a class="vk" href="#" title=""><i class="fa fa-vk"></i></a></li>
                        <li><a class="instagram" href="#" title=""><i class="fa fa-instagram"></i></a></li>

                    </ul>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="gen-metabox no-margin">
                    <span><i class="fa fa-trophy"></i> Badges</span>
                    <ul class="badged">
                        <li><img src="{{asset('images/badges/tt7.png')}}" alt=""></li>
                        <li><img src="{{asset('images/badges/tt6.png')}}" alt=""></li>
                        <li><img src="{{asset('images/badges/badge21.png')}}" alt=""></li>
                        <li><img src="{{asset('images/badges/badge3.png')}}" alt=""></li>
                        <li><img src="{{asset('images/badges/badge4.png')}}" alt=""></li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!-- General infomations -->
    <div class="central-meta">
        <span class="create-post">Friend's ({{count($list_friend)}}) <a href="timeline-friends2.html" title="">See All</a></span>
        <ul class="frndz-list">
            @foreach($list_friend as $i)
            <li>
                <img style="width:154px;height:154px" src="{{asset($i->user_info->Avatar_pic)}}" alt="">
                <div  class="sugtd-frnd-meta img-fluid">
                    <a href="#" title="">{{$i->name}}</a>
                    <ul class="add-remove-frnd">
                        <li class="add-tofrndlist"><a class="send-mesg" href="#" title="Send Message"><i class="fa fa-commenting"></i></a></li>
                        <li class="remove-frnd"><a href="#" title="remove friend"><i class="fa fa-user-times"></i></a></li>
                    </ul>
                </div>
            </li>
            @endforeach
        </ul>
    </div><!-- friends list -->
    <div class="central-meta">
        <span class="create-post">Photos ({{count($list_photos)}}) <a href="timeline-photos.html" title="">See All</a></span>
        <ul class="photos-list">
            @foreach($list_photos as $i)
            <li>
                <div class="item-box">
                    <a class="strip" href="{{asset('images/uploads/'.$i->post_image)}}" title="" data-strip-group="mygroup" data-strip-group-options="loop: false">
                        <img src="{{asset('images/uploads/'.$i->post_image)}}" alt=""></a>
                    <div class="over-photo">
                        <div class="likes heart" title="Like/Dislike">❤ <span>15</span></div>
                        <span>20 hours ago</span>
                    </div>
                </div>
            </li>
            @endforeach
        </ul>
    </div><!-- Photos -->
    <div class="central-meta">
        <span class="create-post">Videos (33) <a href="timeline-videos.html" title="">See All</a></span>
        <ul class="videos-list">
            <li>
                <div class="item-box">
                    <a href="https://www.youtube.com/watch?v=fF382gwEnG8&amp;t=1s" title="" data-strip-group="mygroup" class="strip" data-strip-options="width: 700,height: 450,youtube: { autoplay: 1 }"><img src="{{asset('images/resources/vid-11.jpg')}}" alt="">
                        <i>
                            <svg version="1.1" class="play" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="50px" width="50px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
                                <path class="stroke-solid" fill="none" stroke="" d="M49.9,2.5C23.6,2.8,2.1,24.4,2.5,50.4C2.9,76.5,24.7,98,50.3,97.5c26.4-0.6,47.4-21.8,47.2-47.7
													C97.3,23.7,75.7,2.3,49.9,2.5" />
                                <path class="icon" fill="" d="M38,69c-1,0.5-1.8,0-1.8-1.1V32.1c0-1.1,0.8-1.6,1.8-1.1l34,18c1,0.5,1,1.4,0,1.9L38,69z" />
                            </svg>
                        </i>
                    </a>
                    <div class="over-photo">
                        <div class="likes heart" title="Like/Dislike">❤ <span>15</span></div>
                        <span>20 hours ago</span>
                    </div>
                </div>
            </li>
        </ul>
    </div><!-- Videos -->
</div>
@endsection
