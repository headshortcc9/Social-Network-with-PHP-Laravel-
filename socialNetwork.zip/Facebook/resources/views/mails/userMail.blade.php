{{$text}}
{!!$file!!}


