<?php $__env->startSection('sub_content'); ?>
<div class="col-lg-3">
    <aside class="sidebar static left">

        <div class="advertisment-box">
            <h4 class="">advertisment</h4>
            <figure>
                <a href="#" title="Advertisment"><img src="<?php echo e(asset('images/resources/ad-widget.gif')); ?>" alt=""></a>
            </figure>
        </div>
        <div class="widget">
            <h4 class="widget-title">Shortcuts</h4>
            <ul class="naves">
                <li>
                    <i class="ti-clipboard"></i>
                    <a href="newsfeed.html" title="">News feed</a>
                </li>
                <li>
                    <i class="ti-mouse-alt"></i>
                    <a href="inbox.html" title="">Inbox</a>
                </li>
                <li>
                    <i class="ti-files"></i>
                    <a href="fav-page.html" title="">My pages</a>
                </li>
                <li>
                    <i class="ti-user"></i>
                    <a href="timeline-friends.html" title="">friends</a>
                </li>
                <li>
                    <i class="ti-image"></i>
                    <a href="timeline-photos.html" title="">images</a>
                </li>
                <li>
                    <i class="ti-video-camera"></i>
                    <a href="timeline-videos.html" title="">videos</a>
                </li>
                <li>
                    <i class="ti-comments-smiley"></i>
                    <a href="messages.html" title="">Messages</a>
                </li>
                <li>
                    <i class="ti-bell"></i>
                    <a href="notifications.html" title="">Notifications</a>
                </li>
                <li>
                    <i class="ti-share"></i>
                    <a href="people-nearby.html" title="">People Nearby</a>
                </li>
                <li>
                    <i class="fa fa-bar-chart-o"></i>
                    <a href="insights.html" title="">insights</a>
                </li>
                <li>
                    <i class="ti-power-off"></i>
                    <a href="landing.html" title="">Logout</a>
                </li>
            </ul>
        </div><!-- Shortcuts -->
    </aside>
</div><!-- sidebar -->
<div class="col-lg-6">
    <div class="central-meta postbox">
        <span class="create-post">Create post</span>
        <div class="new-postbox">
            <figure>
                <img class='img-fluid avatar_img' src="<?php echo e(asset(Auth::user()->user_info->Avatar_pic)); ?>" alt="">
            </figure>
            <div class="newpst-input">
                <form method="post">
                    <textarea rows="2" placeholder="Share some what you are thinking?"></textarea>
                </form>
            </div>
            <div class="attachments">
                <ul>
                    <li>
                        <span class="add-loc">
                            <i class="fa fa-map-marker"></i>
                        </span>
                    </li>
                    <li>
                        <i class="fa fa-music"></i>
                        <label class="fileContainer">
                            <input type="file">
                        </label>
                    </li>
                    <li>
                        <i class="fa fa-image"></i>
                        <label class="fileContainer">
                            <input type="file">
                        </label>
                    </li>
                    <li>
                        <i class="fa fa-video-camera"></i>
                        <label class="fileContainer">
                            <input type="file">
                        </label>
                    </li>
                    <li>
                        <i class="fa fa-camera"></i>
                        <label class="fileContainer">
                            <input type="file">
                        </label>
                    </li>
                    <li class="preview-btn">
                        <button class="post-btn-preview" type="submit" data-ripple="">Preview</button>
                    </li>
                </ul>
                <button class="post-btn" type="submit" data-ripple="">Post</button>
            </div>
            <div class="add-location-post">
                <span>Drag map point to selected area</span>
                <div class="row">

                    <div class="col-lg-6">
                        <label class="control-label">Lat :</label>
                        <input type="text" class="" id="us3-lat" />
                    </div>
                    <div class="col-lg-6">
                        <label>Long :</label>
                        <input type="text" class="" id="us3-lon" />
                    </div>
                </div>
                <!-- map -->
                <div id="us3"></div>
            </div>
        </div>

    </div><!-- add post new box -->
    <div class="central-meta">
        <span class="create-post">Suggested Friend's <a href="#" title="">See All</a></span>
        <ul class="suggested-frnd-caro">
            <?php $__currentLoopData = $suggested_friend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <img style="width:141px;height:188px"  class='h-100 w-100 img-fluid' src="<?php echo e(asset($i->user_info->Avatar_pic)); ?>" alt="">
                <div class="sugtd-frnd-meta">
                    <a href="<?php echo e($i->id); ?>" title=""><?php echo e($i->name); ?></a>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div><!-- suggested friends -->
    <div class="loadMore">
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="central-meta item">
            <div class="user-post">
                <div class="friend-info">
                    <figure>
                        <img  src=" <?php echo e(asset($i->User->user_info->Avatar_pic)); ?>" alt="">
                    </figure>
                    <div class="friend-name">
                        <div class="more">
                            <div class="more-post-optns"><i class="ti-more-alt"></i>
                                <ul>
                                    <li><i class="fa fa-pencil-square-o"></i>Edit Post</li>
                                    <li><i class="fa fa-trash-o"></i>Delete Post</li>
                                    <li class="bad-report"><i class="fa fa-flag"></i>Report Post</li>
                                    <li><i class="fa fa-bell-slash-o"></i>Turn off Notifications</li>
                                </ul>
                            </div>
                        </div>
                        <ins><a href="time-line.html" title=""><?php echo e($i->User->name); ?></a></ins>
                        <span><i class="fa fa-globe"></i> published: <?php echo e($i->created_at); ?> </span>
                    </div>
                    <!--Post-info-->
                    <div class="post-meta">
                        <p>
                            <?php echo e($i->post_content); ?>

                        </p> <!-- Text -->
                        <figure>
                            <div class="img-bunch">
                                <div class="row" style="">
                                    <div class="col-lg-3 col-md-3 col-sm-3"></div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <figure>
                                            <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                <img src="<?php echo e(asset('images/uploads/'.$i->post_image)); ?>" alt="">
                                            </a>
                                        </figure>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3"></div>
                                </div>
                            </div> <!-- images -->
                            <ul class="like-dislike">
                                <li><a class="bg-blue" href="#" title="Like Post"><i class="ti-thumb-up"></i></a></li>
                                <li><a class="bg-red" href="#" title="dislike Post"><i class="ti-thumb-down"></i></a></li>
                            </ul> <!-- Reaction -->
                        </figure>

                    </div>
                    <!--Post-content-->
                    <div class="coment-area" style="display: block;">
                        <ul class="we-comet">
                            <li>
                                <a href="#" title="" class="showmore underline">more comments+</a>
                            </li>
                            <li class="post-comment">
                                <div class="comet-avatar">
                                    <img src=" <?php echo e(asset(Auth::user()->user_info->Avatar_pic)); ?>" alt="">
                                </div>
                                <div class="post-comt-box">
                                    <form method="post">
                                        <textarea placeholder="Post your comment"></textarea>
                                        <div class="add-smiles">
                                            <div class="uploadimage">
                                                <i class="fa fa-image"></i>
                                                <label class="fileContainer">
                                                    <input type="file">
                                                </label>
                                            </div>
                                            <span class="em em-expressionless" title="add icon"></span>
                                            <div class="smiles-bunch">
                                                <i class="em em---1"></i>
                                                <i class="em em-smiley"></i>
                                                <i class="em em-anguished"></i>
                                                <i class="em em-laughing"></i>
                                                <i class="em em-angry"></i>
                                                <i class="em em-astonished"></i>
                                                <i class="em em-blush"></i>
                                                <i class="em em-disappointed"></i>
                                                <i class="em em-worried"></i>
                                                <i class="em em-kissing_heart"></i>
                                                <i class="em em-rage"></i>
                                                <i class="em em-stuck_out_tongue"></i>
                                            </div>
                                        </div>

                                        <button type="submit"></button>
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div><!-- album post -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><!-- centerl meta -->
<div class="col-lg-3">
    <aside class="sidebar static right">
        <div class="widget">
            <h4 class="widget-title">Profile intro</h4>
            <ul class="short-profile">
                <li>
                    <span>about</span>
                    <p>Hi, i am jhon kates, i am 32 years old and worked as a web developer in microsoft </p>
                </li>
                <li>
                    <span>fav tv show</span>
                    <p>Sacred Games, Spartcus Blood, Games of Theron </p>
                </li>
                <li>
                    <span>favourit music</span>
                    <p>Justin Biber, Shakira, Nati Natasah</p>
                </li>
            </ul>
        </div>


    </aside>
</div><!-- sidebar -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/users/timeline.blade.php ENDPATH**/ ?>