<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class relationship extends Model
{
    use HasFactory;
    protected $fillable = [
        'user1',
        'user2',
        'status',
    ];
    function p_chat(){
        return $this->hasMany('App\Models\p_chat');
    }
}
