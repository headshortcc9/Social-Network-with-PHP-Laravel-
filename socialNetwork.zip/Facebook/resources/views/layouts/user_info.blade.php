@extends('layouts.temp2')

@section('content')
<section>
    <div class="gap2 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row merged20" id="page-contents">
                        <div class="user-profile">
                            <figure>
                                <div class="edit-pp">
                                    <label class="fileContainer">
                                        <i class="fa fa-camera"></i>
                                        <form id='change-cover-pic' action="" method="post" enctype="multipart/form-data">
                                            <input name='cover_img' data-url='{{ route('setting')}}' type="file">
                                            <input type="hidden" name='function' value="change-cover-pic">
                                        </form>
                                    </label>
                                </div>
                                <img class='cover_img' src="{{asset(Auth::user()->user_info->Cover_pic)}}" alt="">


                            </figure>

                            <div class="profile-section">
                                <div class="row">
                                    <div class="col-lg-2 col-md-3">
                                        <div class="profile-author">
                                            <div class="profile-author-thumb">
                                                <img id='avatar-profile' class='avatar_img_x img-fluid' alt="author" src="{{asset(Auth::user()->user_info->Avatar_pic)}}">
                                                <div class="edit-dp">
                                                    <label class="fileContainer">
                                                        <i class="fa fa-camera"></i>
                                                        <form id='change-avatar-pic' action="" method="post" enctype="multipart/form-data">
                                                            <input  type="file" data-url='{{ route('setting')}}' name='avatar_pic'>
                                                            <input type="hidden" name='function' value="change-avatar-pic">
                                                        </form>
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="author-content">
                                                <a class="h3 author-name" href="about.html">{{Auth::user()->name}}</a>
                                                <div class="country">{{Auth::user()->user_info->Country}}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-10 col-md-9">
                                        <ul class="profile-menu">
                                            <li>
                                                <a class="@php if(url()->current()==url('user/timeline')) echo 'active'; @endphp" href="{{url('user/timeline')}}">Timeline</a>
                                            </li>
                                            <li>
                                                <a class="@php if(url()->current()==url('user/about')) echo 'active'; @endphp" href="{{url('user/about')}}">About</a>
                                            </li>
                                            <li>
                                                Friends
                                            </li>
                                            <li>
                                                Photos
                                            </li>
                                            <li>
                                               Videos
                                            </li>

                                        </ul>
                                        <ol class="folw-detail">
                                            <li><span>Posts</span><ins>{{$post_no}}</ins></li>
                                            <li><span>Followers</span><ins>1.3K</ins></li>
                                            <li><span>Following</span><ins>22</ins></li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div><!-- user profile banner  -->
                        @yield('sub_content')
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- content -->
@endsection
