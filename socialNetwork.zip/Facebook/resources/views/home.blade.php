@extends('layouts.temp2')
@section('sidebar-right')
<div class="fixed-sidebar right">
    <div class="">
        <div class="dob-head">
            <img src="{{asset('images/resources/darius2.jpg')}}" alt="">
            <span>22nd Birthday</span>
            <div class="dob">
                <i>19</i>
                <span>September</span>
            </div>
        </div>
        <div class="dob-meta">
            <figure><img src="{{asset('images/resources/dob-cake.gif')}}" alt=""></figure>
            <h6><a href="#" title="">Darius</a> 's birthday</h6>
            <p>leave a message with your best wishes on his profile.</p>
        </div>
    </div>

    <div class="chat-friendz">
        <div class='text-left px-2 py-2'>
            <h5 class='d-inline-block'>Contacts </h5>
            <div class='float-right'>
                <i class='fa fa-video px-2'></i>
                <i class='fa fa-search px-2'></i>
                <i class='ti-more-alt px-2'></i>
            </div>
        </div>
        <ul class="chat-users">
            @foreach($list_friend as $i)
            <li>
                <div class="author-thmb">
                    <img class='avatar_img' src="{{asset($i->user_info->Avatar_pic)}}" alt="">
                    <input type="hidden" name='partner_id' value="{{$i->id}}">
                    <input type="hidden" name='partner_email' value="{{$i->email}}">
                    <span class='mx-2'>{{$i->name}}</span>
                    <span class="status f-online"></span>
                    <a class='float-lg-right m-2' href="" title="Send mail"><i class='ti-email'></i></a>
                </div>
            </li>
            @endforeach
        </ul>
        <div class="chat-box">
            <div class="chat-head">
                <img style='width:40px;height:40px' class='rounded-circle'
                    src="{{asset('images/resources/kaisa2.jpg')}}" alt="">
                <!-- <span class="status f-online"></span> -->
                <h6>Kaisa</h6>
                <div class="more">
                    <i class='fa fa-phone mx-1'></i>
                    <i class='fa fa-video mx-1'></i>
                    <div class="more-optns"><i class="ti-more-alt"></i>
                        <ul>
                            <li>block chat</li>
                            <li>unblock chat</li>
                            <li>conversation</li>
                        </ul>
                    </div>
                    <span class="close-mesage"><i class="ti-close"></i></span>
                </div>

            </div>
            <div class="chat-list1" id='chat-1'>
                <ul id='chat-wrap' class='py-2 px-1'>

                </ul>

            </div>
            <form id='form_chat' class="text-box1">
                <textarea id='sendie' name="mesage" placeholder="Post enter to post..."></textarea>
                <input type="hidden" name='rel_id' value="">
                <input id='chat_img' style='font-size:8px' type="file" name='chat_image'>
            </form>
        </div>
    </div>
</div><!-- right sidebar user chat -->
@endsection
@section('content')
<div class="gap2 gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row merged20" id="page-contents">
                    <div class="col-lg-2">
                        <aside class="sidebar static left">
                            <div class="advertisment-box">
                                <h4 class="">advertisment</h4>
                                <figure class="bg-dark">
                                    <a href="#" title="Advertisment"><img src="{{asset('images/resources/tt.gif')}}"
                                            alt=""></a>
                                </figure>
                            </div>
                            <div class="widget">
                                <h4 class="widget-title">Shortcuts</h4>
                                <ul class="naves">
                                    <li>
                                        <i class="ti-clipboard"></i>
                                        <a href="" title="">News feed</a>
                                    </li>
                                    <li>
                                        <i class="ti-mouse-alt"></i>
                                        <a href="" title="">Inbox</a>
                                    </li>
                                    <li>
                                        <i class="ti-files"></i>
                                        <a href="" title="">My pages</a>
                                    </li>
                                    <li>
                                        <i class="ti-user"></i>
                                        <a href="user/friends" title="">friends</a>
                                    </li>
                                    <li>
                                        <i class="ti-image"></i>
                                        <a href="user/photos" title="">images</a>
                                    </li>
                                    <li>
                                        <i class="ti-video-camera"></i>
                                        <a href="user/videos" title="">videos</a>
                                    </li>
                                    <li>
                                        <i class="ti-comments-smiley"></i>
                                        <a href="" title="">Messages</a>
                                    </li>
                                    <li>
                                        <i class="ti-bell"></i>
                                        <a href="" title="">Notifications</a>
                                    </li>
                                    <li>
                                        <i class="ti-share"></i>
                                        <a href="" title="">People Nearby</a>
                                    </li>
                                    <li>
                                        <i class="fa fa-bar-chart-o"></i>
                                        <a href="" title="">insights</a>
                                    </li>

                                </ul>
                            </div>

                        </aside>
                    </div><!-- sidebar -->
                    <div class="col-lg-8">
                        <div class="central-meta">
                            <span class="create-post">Recent Stories <a href="#" title="">See All</a></span>
                            <div class="story-postbox">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/Viego1.jpg')}}" alt="">
                                                <span>Add Your Story</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip"
                                                title="{{Auth::user()->name}}">
                                                <i class="fa fa-plus"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/Yone1.jpg')}}" alt="">
                                                <span>Yone</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Yone">
                                                <img src=" {{asset('images/resources/yone2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/kaisa1.jpg')}}" alt="">
                                                <span>Kaisa</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Kaisa">
                                                <img src=" {{asset('images/resources/kaisa2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/darius1.jpg')}}" alt="">
                                                <span>Darius</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Darius">
                                                <img src=" {{asset('images/resources/darius2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- top stories -->
                        <div id='post_area' class="central-meta postbox">
                            <span class="create-post">Create post</span>
                            <div class="new-postbox">
                                <figure>
                                    <img class='avatar_img' src=" {{asset(Auth::user()->user_info->Avatar_pic)}}"
                                        alt="">
                                </figure>
                                <div class="newpst-input">
                                    <form id='formPostContent' method="post">
                                        <textarea name='postContent' rows="2"
                                            placeholder="Share some what you are thinking?"></textarea>
                                        <input type="hidden" name='image_path' value=''>
                                    </form>
                                    <div id="postnxn-review" class="row">
                                        <!-- <div class='col-lg-6 col-md-6 col-sm-6 px-1 my-1'>
                                            <img src="public/images/uploads/user4-1624940968/post/post-1624970440FB_IMG_1579277012413.jpg" alt="">
                                            <a><i class='fa fa-trash'></i></a>
                                        </div> -->
                                    </div>

                                </div>
                                <div class="attachments">
                                    <ul>
                                        <li>
                                            <i class="fa fa-image"></i>
                                            <label class="fileContainer">
                                                <form id='formPostImage' action="" method="post"
                                                    enctype="multipart/form-data">
                                                    <input type="file" name='postImage'
                                                        data-url="{{route('imageProcess')}}">
                                                </form>
                                            </label>
                                        </li>
                                    </ul>
                                    <button id='submitPost' class="post-btn" type="submit" data-ripple="">Post</button>

                                </div>
                            </div>
                        </div><!-- add post new box -->
                        <div class="loadMore">
                            @for($i=count($post)-1;$i>=0;$i--)
                            <div class="central-meta item">
                                <div class="user-post">
                                    <div class="friend-info">
                                        <figure>
                                            <img src=" {{asset($post[$i]->User->user_info->Avatar_pic)}}" alt="">
                                        </figure>
                                        <div class="friend-name">
                                            <div class="more">
                                                <div class="more-post-optns"><i class="ti-more-alt"></i>
                                                    <ul>
                                                        <li class="bad-report"><i class="fa fa-flag"></i>Report Post
                                                        </li>
                                                        <li><i class="fa fa-bell-slash-o"></i>Turn off Notifications
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <ins><a href="time-line.html" title="">{{$post[$i]->User->name}}</a></ins>
                                            <span><i class="fa fa-globe"></i> published: {{$post[$i]->created_at}} </span>
                                        </div>
                                        <!--Post-info-->

                                        <div class="post-meta">
                                            <p>
                                                {!!$post[$i]->post_content!!}
                                            </p>
                                            <!-- Text -->
                                            <figure>
                                                <div class="img-bunch">
                                                    <div class="row">
                                                        <div class="col-lg-3 col-md-3 col-sm-3"></div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal"
                                                                    data-target="#img-comt">
                                                                    <img src="{{asset('images/uploads/'.$post[$i]->post_image)}}"
                                                                        alt="">
                                                                </a>
                                                            </figure>
                                                        </div>
                                                        <div class="col-lg-3 col-md-3 col-sm-3"></div>
                                                    </div>
                                                </div> <!-- images -->
                                                <ul class="like-dislike">
                                                    <li><a class="bg-blue like" data-id={{$post[$i]->id}} title="Like Post"><i
                                                                class="ti-thumb-up"></i></a></li>
                                                    <li><a class="bg-red dislike" data-id={{$post[$i]->id}}
                                                            title="dislike Post"><i class="ti-thumb-down"></i></a></li>
                                                </ul> <!-- Reaction -->
                                            </figure>
                                            <div class="we-video-info">
                                                <ul>
                                                    <li>
                                                        <div class="likes heart text-danger" title="Like/Dislike"><i class='fa fa-thumbs-up'></i><span>{{$post[$i]->post_like}}</span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="likes heart text-secondary" title="Like/Dislike"><i class='fa fa-thumbs-down'></i><span>{{$post[$i]->post_dislike}}</span>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <span data-id={{$post[$i]->id}} class="comment text-primary" title="Comments">
                                                            <i class="fa fa-commenting"></i>
                                                            <ins>52</ins>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <!--Post-content-->
                                        <div class="coment-area" style="display: block;">
                                            <ul class="we-comet">
                                                <li class='cho'>
                                                    <a data-id={{$post[$i]->id}} href="#" title="" class="showmore underline">more comments+</a>
                                                </li>
                                                <li class="post-comment">
                                                    <div class="comet-avatar">
                                                        <img src=" {{asset(Auth::user()->user_info->Avatar_pic)}}"
                                                            alt="">
                                                    </div>
                                                    <div class="post-comt-box">
                                                        <form method="post">
                                                            <textarea name='post_content' placeholder="Post your comment"></textarea>
                                                            <input type="hidden" name='p_id' value={{$post[$i]->id}}>
                                                            <div class="add-smiles">
                                                                <div class="uploadimage">
                                                                    <i class="fa fa-image"></i>
                                                                    <label class="fileContainer">
                                                                        <input type="file">
                                                                    </label>
                                                                </div>
                                                                <span class="em em-expressionless"
                                                                    title="add icon"></span>
                                                                <div class="smiles-bunch">
                                                                    <i class="em em---1"></i>
                                                                    <i class="em em-smiley"></i>
                                                                    <i class="em em-anguished"></i>
                                                                    <i class="em em-laughing"></i>
                                                                    <i class="em em-angry"></i>
                                                                    <i class="em em-astonished"></i>
                                                                    <i class="em em-blush"></i>
                                                                    <i class="em em-disappointed"></i>
                                                                    <i class="em em-worried"></i>
                                                                    <i class="em em-kissing_heart"></i>
                                                                    <i class="em em-rage"></i>
                                                                    <i class="em em-stuck_out_tongue"></i>
                                                                </div>
                                                            </div>

                                                        </form>
                                                    </div>
                                                </li>

                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <!-- album post -->
                            @endfor
                        </div>
                    </div><!-- centerl meta -->
                </div>
                <div id='u-mail-area' class='shadow-lg'>
                    <div class="header">
                        New message
                        <a href="" class='float-lg-right'><i class='ti-close'></i></a>
                    </div>
                    <form action="" method="post">
                        <h6 class="m-2">To :nghianx.t94@gmail.com</h6>
                        <div class="form-group m-2">
                            <input type="text" class="form-control" name='header' aria-describedby="emailHelp"
                                placeholder="Header mail">
                        </div>
                        <div class="form-group m-2">
                            <textarea class="form-control" id="exampleFormControlTextarea1" name='text'
                                rows="10"></textarea>

                        </div>
                        <input type="hidden" name='u_id' value="">
                        <input type="file" class='form-control-file' name='u-mail_file'>
                        <button type="submit" class='btn btn-primary mx-2'>Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

