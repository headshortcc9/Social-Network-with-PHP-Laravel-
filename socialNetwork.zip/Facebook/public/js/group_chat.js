function g_Chat() {
    g_state = 0;
    g_id = 0;
    //get state of chat
    this.get_state = function(id) {
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url: "chat-msg/get_state",
            type: "POST",
            cache: false,
            data: {
                'group_id': id
            },
            dataType: "json",
            success: function(data) {
                //$('#form_chat input[type=hidden]').val(data['rel_id']);
                g_id = data['g_id'];
                //g_state = data['state'];
                g_update();
                //console.log(data);
            }
        });
    };
    //update
    this.update = g_update;
}
//
function g_update() {
    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "chat-msg/update_chat",
        type: "POST",
        cache: false,
        data: {
            'g_id': g_id,
            'state': g_state
        },
        dataType: "json",
        success: function(data) {
            var str = " ";
            if (data['change'] == true) {
                data['lines'].forEach(i => {
                    if (i['who'] == 'me') {
                        str += "<li class='me'>" +
                            " <div class='w-75 d-inline-block'>" +
                            " <span class='chat-message-item text-left'>" + i['text'] +
                            "</span>" +
                            " <img src='";
                        if (i['image'] != null) str += i['image'];
                        str += "'>" +
                            "<span class='notification-date'><time class='entry-date updated'>" + i['time'] + "</time></span>" +
                            "</div>" +
                            "</li>"

                    } else {
                        str += "<li class='you'>" +
                            " <div class='row'>" +
                            " <div class='col-md-2 py-2 pl-0 pr-2 text-right'>" +
                            " <img style='width:30px ; height:30px' class='rounded-circle' src='public/" + i['user_img'] + "'>" +
                            "</div>" +
                            "<div class='col-md-8 p-0'>" +
                            " <span class='chat-message-item'>" + i['text'] +
                            "</span>" +
                            " <img src='";
                        if (i['image'] != null) str += i['image'];
                        str += "'>" +
                            "<span class='notification-date'><time class='entry-date updated'>" + i['time'] + "</time></span>" +
                            "</div>" +
                            "<div class='col-md-2'></div>" +
                            "</div>"
                    }
                    $('.chat-list1 ul').append(str);
                    str = " ";
                    document.getElementById("chat-1").scrollTop = document.getElementById("chat-wrap").scrollHeight;
                });
                g_state = data['state'];
            }

            console.log(data);
        }
    });
    //setTimeout(g_update, 1500);
}
$(document).ready(function() {
    //create new group
    //{
    $('#btn-new-group').on('click', function(e) {
        e.preventDefault();
        $('#g-chat-area #create-group').show();
    });
    $('#g-chat-area #create-group form a').on('click', function(e) {
        e.preventDefault();
        $('#g-chat-area #create-group').hide();
    });
    $('#g-chat-area #create-group form button').click(function(e) {
        e.preventDefault();
        $('#g-chat-area #create-group form').submit();
    });
    //
    $('#g-chat-area #create-group form').submit(function(e) {
        e.preventDefault();
        //
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "chat-msg/create",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] != 1) {
                    location.reload();
                    $('#g-chat-area #create-group form input').val("");
                    $('#g-chat-area #create-group').hide();

                } else {

                    console.log(data);
                }
            }
        });
    });
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    //add member for group
    //{
    $('#list-owner-group .add-member').click(function(e) {
        e.preventDefault();
        var id = $(this).attr('data-id');
        $('#choose-mem input[type=hidden]').val(id);
        $('#choose-mem').show();
    });
    //
    $('#g-chat-area #choose-mem form a').on('click', function(e) {
        e.preventDefault();
        $('#g-chat-area #choose-mem').hide();
    });

    //
    $('#g-chat-area #choose-mem form button').click(function(e) {
        e.preventDefault();
        $('#g-chat-area #choose-mem form').submit();
    });
    //
    $('#g-chat-area #choose-mem form').submit(function(e) {
        e.preventDefault();
        //
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "chat-msg/add-mem",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                if (data['error'] != 1) {
                    $('#g-chat-area #choose-mem').hide();
                } else {

                    console.log(data);
                }
                //console.log(data);
            }
        });
    });
    //}
    //---------------------------------------------------------------------------------
    //----------------------------------------------------------------------------------
    //load chat conversations
    //{
    $('#list-owner-group>li').click(function(e) {
        e.preventDefault();
        var g_id = $(this).attr('data-id');
        var unload = $('#g_form_chat .text-area input[type=hidden]').val();
        if (g_id != unload) {
            var img = $(this).children().children('figure').children('img').attr('src');
            var name = $(this).children().children('.user-name').children('h6').text();
            $('.active-user img').attr('src', img);
            $('.active-user h6').text(name);
            $('#g_form_chat .text-area input[type=hidden]').val(g_id);
            $('.chater-info img').attr('src', img);
            $('.chater-info h6').text(name);
            $('#mail-area form input[type=hidden]').val(g_id);
            $('.userabout ul').empty();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: "chat-msg/loadMember",
                type: "POST",
                cache: false,
                data: {
                    'group_id': g_id
                },
                dataType: "json",
                success: function(data) {
                    for (let i of data['member']) {
                        var str = " <li>" +
                            "<div class='form-check'>" +
                            " <input class='form-check-input' type='checkbox' name='user_id[]' value=" + i['id'] + ">" +
                            "<label class='form-check-label'>" + i['name'] + "</label>" +
                            " </div>" +
                            "</li>"
                        $('.userabout ul').append(str);
                        //console.log(i);
                    };

                }
            });
            //
            var chat = new g_Chat();
            chat.get_state(g_id);
        } else {
            g_update();
        }
    });
    //chat process
    $('#g_sendie').keydown(function() {
        var key = event.which;
        $("#g_sendie").css("background-color", "yellow");
    });
    $('#g_sendie').keyup(function(e) {
        e.preventDefault();
        var key = event.which;
        if (key == 13) {
            $('#g_form_chat').submit();
            $('#g_sendie').val(" ");
            document.getElementById("g_chat_img").value = "";

        }
        $("#g_sendie").css("background-color", "pink");
    });
    $('#g_form_chat').submit(function(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "chat-msg/send_chat",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                g_update();
                //console.log(data);
            }
        });
    });
    //send mail
    $('#mail-area .header a').on('click', function(e) {
        e.preventDefault();
        $('#g-chat-area #mail-area').hide();
    });
    $('.live-calls #g_send_mail').on('click', function(e) {
        e.preventDefault();
        $('#g-chat-area #mail-area').show();
    });
    $('#mail-area form button').click(function(e) {
        e.preventDefault();
        $(this).parent().submit();
    });
    $('#mail-area form').submit(function(e) {
        e.preventDefault();
        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: "POST",
            url: "chat-msg/send-mail",
            cache: false,
            data: new FormData(this),
            processData: false,
            contentType: false,
            dataType: "json",
            success: function(data) {
                alert('Your email has been send to all member in group!');
                $('#g-chat-area #mail-area').hide();
            }
        });
    });
});
