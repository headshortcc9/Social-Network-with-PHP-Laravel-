<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class user_gchat extends Model
{
    protected $fillable=[
        'user_id',
        'g_chat_id'
    ];
    protected $table="g_chat_user";
    use HasFactory;
}
