<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class p_chat extends Model
{
    use HasFactory;
    protected $fillable = [
        'relationship_id',
        'user_id',
        'image',
        'text'
    ];
    function relationship(){
        return $this->belongsTo('App\Models\relationship');
    }
    function user(){
        return $this->belongsTo('App\Models\User');
    }

}
