<?php

namespace App\Http\Controllers\users;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Mail\normalMail;
use App\Models\relationship;
use App\Models\p_chat;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class chatController extends Controller
{
    function get_state_of_chat()
    {
        $log = array();
        $partner_id = $_POST['partner_id'];
        $rel = relationship::where([
            ['user1', Auth::user()->id],
            ['user2', $partner_id],
        ])
            ->orWhere([
                ['user2', Auth::user()->id],
                ['user1', $partner_id],
            ])->first();
        $line_chats = $rel->p_chat;
        $log['state'] = count($line_chats);
        $log['rel_id'] = $rel->id;
        echo json_encode($log);
    }
    function update_chat()
    {
        $log = array();
        $log['bug'] = (int)$_POST['state'];
        $log['lines'] = array();
        $data_state = count(relationship::find($_POST['rel_id'])->p_chat);
        if ($_POST['state'] == 0) {
            $tmp = array();
            foreach (relationship::find($_POST['rel_id'])->p_chat as $i) {
                $tmp['user_id'] = $i->user->id;
                $tmp['user_img'] = $i->user->user_info->Avatar_pic;
                $tmp['text'] = $i->text;
                $tmp['image'] = $i->image;
                $tmp['rel_id'] = $i->relationship_id;
                $tmp['time'] = $i->created_at;
                if ($i->user->id == Auth::user()->id) $tmp['who'] = 'me';
                else  $tmp['who'] = 'you';
                $log['lines'][] = $tmp;
            }
            $log['state'] = $data_state;
            $log['change']=true;
        } else if ($_POST['state'] < $data_state) {
            $record = DB::select("CALL get_new_lines(".$_POST['state'].",".$_POST['rel_id'].")");
            $tmp = array();
            foreach ($record as $i) {
                $tmp['user_id'] = $i->user_id;
                $u=User::find($i->user_id);
                $tmp['user_img'] = $u->user_info->Avatar_pic;
                $tmp['text'] = $i->text;
                $tmp['image'] = $i->image;
                $tmp['rel_id'] = $i->relationship_id;
                $tmp['time'] = $i->created_at;
                if ($i->user_id== Auth::user()->id) $tmp['who'] = 'me';
                else  $tmp['who'] = 'you';
                $log['lines'][] = $tmp;
            }
            $log['state'] = $data_state;
            $log['change']=true;
        }else{
            $log['change']=false;
        }

        echo json_encode($log);
    }
    function send_chat()
    {
        $log = array();
        $data=array();

        //image process
        if (!empty($_FILES['chat_image'])) {
            $ext = pathinfo($_FILES['chat_image']['name'], PATHINFO_EXTENSION);
            $allowed = ['png', 'jpg', 'jpeg'];
            //
            if (in_array($ext, $allowed)) {
                $sourcePath = $_FILES['chat_image']['tmp_name']; // Storing source path of the file in a variable
                $new_name=time() . $_FILES['chat_image']['name'];
                $targetPath = "public/images/uploads/chat_image/" . $new_name; // Target path where file is to be stored
                if (move_uploaded_file($sourcePath, $targetPath)) {
                    $data['image']="public/images/uploads/chat_image/" . $new_name;
                } else {
                    $log['img_error'] = 'Fail to upload image!';
                }
            } else {
                $log['img_error'] = 'This file not supported!';
            }
        }else $log['empty_image']=true;
        //text process
        if(!empty($_POST['mesage'])){
            //$line=str_replace("\n","",$_POST['mesage']);
            $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
            $message=htmlentities(strip_tags($_POST['mesage']));
            if(($message) != "\n"){
                if(preg_match($reg_exUrl,$message,$url)){
                    $message=preg_replace($reg_exUrl,'<a href="'.$url[0].'" target="_blank">'.$url[0].'</a>',$message);
                }
            }
            $data['text']=$message;
        }else $log['empty_text']=true;
        //database process
        if(!empty($log['empty_image']) and !empty($log['empty_text'])) $log['empty']=true;
        else{
            $data['relationship_id']=$_POST['rel_id'];
            $data['user_id']=Auth::user()->id;
            p_chat::create($data);
        }
        echo json_encode($log);
    }
    //mail
    function send_mail(){
        $log=array();
        $mailContent=array();
        //
        $mailContent['header']=$_POST['header'];
        $mailContent['text']=$_POST['text'];
        //
        $tmpPath="";
        //
        if (!empty($_FILES['u-mail_file']['name'])) {
            $ext = pathinfo($_FILES['u-mail_file']['name'], PATHINFO_EXTENSION);
            $allowed = ['png', 'jpg', 'jpeg','txt','php','json'];
            //
            if (in_array($ext, $allowed)) {
                $sourcePath = $_FILES['u-mail_file']['tmp_name']; // Storing source path of the file in a variable
                $new_name=time() . $_FILES['u-mail_file']['name'];
                $targetPath = "public/mails/uploads/" . $new_name;
                $tmpPath = "public/mails/uploads/" . $new_name ;// Target path where file is to be stored
                if (move_uploaded_file($sourcePath, $targetPath)) {
                   $fullPath=$_SERVER['SERVER_NAME']."/"."Facebook/".$targetPath;
                   $mailContent['file']="<a href='".$fullPath."'>".$new_name."</a>";
                } else {
                    $log['img_error'] = 'Fail to upload image!';
                }
            } else {
                $log['img_error'] = 'This file not supported!';
            }
        }else $log['empty_image']=true;


        $receiver  = User::find((int)$_POST['u_id']);
       Mail::to($receiver->email)->send(new normalMail($mailContent));
        //
       // if($tmpPath!="") unlink($tmpPath);
        //$mailContent['u_email']=$receiver->email;
        echo json_encode($mailContent);
    }
}
