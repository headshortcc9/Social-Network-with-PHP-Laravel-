<?php

namespace App\Http\Controllers\users;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\relationship;
use App\Models\requestAdd;

class friendController extends Controller
{
    function showFriends()
    {

        return View('users.friend');
    }
    function sendRequest()
    {
        $log = array();
        $tmp_que = count(requestAdd::where([
            ['sender_id', Auth::user()->id],
            ['receiver_id', $_POST['user_id']]
        ])->orWhere([
            ['receiver_id', Auth::user()->id],
            ['sender_id', $_POST['user_id']]
        ])->get());
       // $log['bug']=$tmp_que;
        if ($tmp_que == 0) {
            $macth_id = time();
            if (requestAdd::create([
                'relationship_id' => $macth_id,
                'receiver_id' => $_POST['user_id'],
                'sender_id' => Auth::user()->id
            ])) $log['error'] = 0;
            else $log['error'] = 1;
        }else $log['error']=1;

        echo json_encode($log);
    }

    function addFriend()
    {
        $log = array();
        $action = relationship::create([
            'user2' => Auth::user()->id,
            'user1' => $_POST['id'],
            'status' => 1
        ]);
        if ($action) {
            if (requestAdd::find($_POST['res_id'])->delete()) $log['error'] = 0;
            else $log['error'] = 1;
        } else $log['error'] = 1;

        echo json_encode($log);
    }
    function unfriend()
    {
        $log = array();
        $action = relationship::where([
            ['user1', (int)$_POST['user_id']],
            ['user2', Auth::user()->id]
        ])->orWhere([
            ['user2', (int)$_POST['user_id']],
            ['user1', Auth::user()->id]
        ])->delete();
        if ($action) {
            $log['error'] = 0;
        } else $log['error'] = 1;

        echo json_encode($log);
    }
    function refuse()
    {
        $log = array();
        if (requestAdd::find($_POST['res_id'])->delete()) $log['error'] = 0;
        else $log['error'] = 1;


        echo json_encode($log);
    }
}
