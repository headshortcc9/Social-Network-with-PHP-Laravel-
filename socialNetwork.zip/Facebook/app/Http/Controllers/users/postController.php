<?php

namespace App\Http\Controllers\users;
use App\Models\User;
use App\Models\Post;
use App\Models\post_pic;
use App\Http\Controllers\Controller;
use App\Models\post_comment;
use FFI\Exception;
use Illuminate\Http\Request;
use SebastianBergmann\Environment\Console;
use Illuminate\Support\Facades\Auth;

class postController extends Controller
{
    //POST
    function createPost()
    {
        $log = array();
        $data= array();
        $data['user_id']=Auth::user()->id;
        $data['post_image']= $_POST['image_path'];

        $log['id']=Auth::user()->id;
        $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
        //$message=htmlentities(strip_tags($_POST['postContent']));
        $message=($_POST['postContent']);
        if($message != "\n"){
            if(preg_match($reg_exUrl,$message,$url)){
                $message=preg_replace($reg_exUrl,'<a href="'.$url[0].'" target="_blank">'.$url[0].'</a>',$message);
                $data['post_content']= $message;
            }else{
                $data['post_content']= $message;
            }
        }
        if(Post::create($data)) $log['error'] = 0;
        else $log['error'] = 1;
        $log['link']= $data['post_content'];
        echo json_encode($log);
    }
    function imageProcess()
    {
        $log['name'] = 'nghia';
        $ext = pathinfo($_FILES['postImage']['name'], PATHINFO_EXTENSION);
        $allowed = ['png', 'jpg', 'jpeg'];
        if (in_array($ext, $allowed)) {
            $sourcePath = $_FILES['postImage']['tmp_name'];
            $targetPath = "public/images/uploads/" . Auth::user()->root_folder . '/post' . '/post-' . time() . $_FILES['postImage']['name']; // Target path where file is to be stored
            $log['dataPath'] = Auth::user()->root_folder . '/post' . '/post-' . time() . $_FILES['postImage']['name'];
            if (move_uploaded_file($sourcePath, $targetPath)) {
                $log['error'] = null;
                $log['post_img'] = "public/images/uploads/" . Auth::user()->root_folder . '/post' . '/post-' . time() . $_FILES['postImage']['name'];
            } else {
                $log['error'] = 'Fail!!';
            }
        } else {
            $log['error'] = 'File not allow!';
        }
        echo json_encode($log);
    }
    function removeImage()
    {
        $log = array();
        if (unlink($_POST['path'])) $log['status'] = 1;
        else $log['status'] = 0;
        echo json_encode($log);
    }
    //
    function like(){
        $log=array();
        try{
            $like = Post::find((int)$_POST['id'])->post_like;
            Post::find((int)$_POST['id'])->update(['post_like'=>$like+1]);
            $log['info']=$like+1;
        }catch(Exception $e){
            $log['error']=1;
        }

        echo json_encode($log);
    }
    function dislike(){
        $log=array();
        try{
            $dislike = Post::find((int)$_POST['id'])->post_dislike;
            Post::find((int)$_POST['id'])->update(['post_dislike'=>$dislike+1]);
            $log['info']=$dislike+1;
        }catch(Exception $e){
        $log['error']=1;
        }
    echo json_encode($log);
    }
    //comment
    function comment(){
        $log=array();
        //$log['bac']=$_POST;
        try{
            post_comment::create([
                'user_id'=>Auth::user()->id,
                'post_id'=>(int)$_POST['p_id'],
                'text'=>htmlentities($_POST['post_content'])
            ]);
        }catch(Exception $e){
            $log['error']=$e;
        }
        $log['text']=$_POST['post_content'];
        $log['name']=Auth::user()->name;
        $log['image']=Auth::user()->user_info->Avatar_pic;
        echo json_encode($log);
    }
    //
    function loadComment(){
        $log=array();
        $log['cmt']=array();
        try{
            $cmt=Post::find((int)$_POST['id'])->post_comment;
        }catch(Exception $e){
            $log['error']=$e;
        }
        foreach($cmt as $i){
            $tmp=array();
            $tmp['user_id']=$i->user_id;
            $tmp['user_name']=$i->user->name;
            $tmp['user_image']=$i->user->user_info->Avatar_pic;
            $tmp['content']=$i->text;
            $tmp['image']=$i->image;
            $tmp['post_id']=$i->post_id;
            $log['cmt'][]=$tmp;
        }
        echo json_encode($log);
    }

}
