<?php echo e($slot); ?>

<?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>