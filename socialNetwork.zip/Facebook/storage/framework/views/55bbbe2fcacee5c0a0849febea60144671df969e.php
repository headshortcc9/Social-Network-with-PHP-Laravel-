<?php echo e($text); ?>

<?php echo $file; ?>



<?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/mails/userMail.blade.php ENDPATH**/ ?>