<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class g_chat extends Model
{
    use HasFactory;
    protected $fillable = [
        'g_name',
        'g_image',
        'user_id'
    ];
    function users(){
        return $this->belongsToMany("App\Models\User");
    }

    function g_chat_line(){
        return $this->hasMany('App\Models\g_chat_line');
    }
}
