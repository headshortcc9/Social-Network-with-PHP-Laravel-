<?php $__env->startSection('content'); ?>


<div class="we-login-register">
    <div class="form-title">
        <!-- <i class="fa fa-key"></i>login -->
        <span>Verify Your Email Address.</span>
    </div>
    <form class="we-form" method="post" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <?php if(session('resent')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

        </div>
        <?php endif; ?>

        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

        <?php echo e(__('If you did not receive the email')); ?>,
        <form class="text-center" method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to request another')); ?></button>
        </form>

    </form>

    <a class="with-smedia facebook" href="#" title="" data-ripple=""><i class="fa fa-facebook"></i></a>
    <a class="with-smedia twitter" href="#" title="" data-ripple=""><i class="fa fa-twitter"></i></a>
    <a class="with-smedia instagram" href="#" title="" data-ripple=""><i class="fa fa-instagram"></i></a>
    <a class="with-smedia google" href="#" title="" data-ripple=""><i class="fa fa-google-plus"></i></a>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/auth/verify.blade.php ENDPATH**/ ?>