<?php

namespace App\Http\Controllers;

use App\Mail\normalMail;
use Illuminate\Support\Facades\DB;
use App\Models\requestAdd;
use App\Models\User;
use App\Models\relationship;
use App\Models\g_chat;
use App\Models\g_chat_line;
use App\Models\user_gchat;
use Exception;
use Illuminate\Http\Request;
use Laravel\Ui\Presets\Vue;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class chatController extends Controller
{
    function showChat()
    {
        $friend_request = array();
        $tmp = requestAdd::where('receiver_id', Auth::user()->id)->get();
        foreach ($tmp as $i) {
            $u = User::find($i->sender_id);
            $arr = [
                'user_img' => $u->user_info->Avatar_pic,
                'user_name' => $u->name,
                'rel_id' => $u->id,
                'res_id' => $i->id,
                'time' => $i->created_at
            ];
            $friend_request[] = $arr;
        }
        //friend
        $relationships = relationship::where('user1', Auth::user()->id)->orWhere('user2', Auth::user()->id)->get();
        $list_friend = array();
        foreach ($relationships as $i) {
            if ($i->user1 == Auth::user()->id) $list_friend[] = User::find($i->user2);
            else $list_friend[] = User::find($i->user1);
        }
        //group

       $list_group = Auth::user()->g_chats;
        //$list_group = g_chat::find(5);
        //$list_group = g_chat::where('user_id',Auth::user()->id)->get();
        return View('chat-message', compact('friend_request', 'list_friend', 'list_group'));
    }
    //
    function getState()
    {
        $log = array();
        $g_id = $_POST['group_id'];
        $rec = g_chat::find($g_id)->g_chat_line;
        $log['state'] = count($rec);
        $log['g_id'] = $g_id;
        echo json_encode($log);
    }
    //
    function update_chat()
    {
        $log = array();
        $log['lines'] = array();
        $log['state1']=$_POST['state'];
        $data_state = count(g_chat::find($_POST['g_id'])->g_chat_line);
        if ($_POST['state'] == 0) {
            $tmp = array();
            foreach (g_chat::find($_POST['g_id'])->g_chat_line as $i) {
                $tmp['user_id'] = $i->user->id;
                $tmp['user_img'] = $i->user->user_info->Avatar_pic;
                $tmp['text'] = $i->text;
                $tmp['image'] = $i->image;
                $tmp['g_id'] = $i->g_chat_id;
                $tmp['time'] = $i->created_at;
                if ($i->user->id == Auth::user()->id) $tmp['who'] = 'me';
                else  $tmp['who'] = 'you';
                $log['lines'][] = $tmp;
            }
            $log['state'] = $data_state;
            $log['change'] = true;
        } else if ($_POST['state'] < $data_state) {
            $record = DB::select("CALL get_g_new_lines(" . $_POST['state'] . "," . $_POST['g_id'] . ")");
            $tmp = array();
            foreach ($record as $i) {
                $tmp['user_id'] = $i->user_id;
                $u = User::find($i->user_id);
                $tmp['user_img'] = $u->user_info->Avatar_pic;
                $tmp['text'] = $i->text;
                $tmp['image'] = $i->image;
                $tmp['g_id'] = $i->g_chat_id;
                $tmp['time'] = $i->created_at;
                if ($i->user_id == Auth::user()->id) $tmp['who'] = 'me';
                else  $tmp['who'] = 'you';
                $log['lines'][] = $tmp;
            }
            $log['state'] = $data_state;
            $log['change'] = true;
        } else {
            $log['change'] = false;
        }

        echo json_encode($log);
    }
    //
    function send_chat()
    {
        $log = array();
        $data=array();
        //image process
       // $log['file']=$_FILES['chat_g_image'];
        if (!empty($_FILES['chat_g_image']['name'])) {
            $ext = pathinfo($_FILES['chat_g_image']['name'], PATHINFO_EXTENSION);
            $allowed = ['png', 'jpg', 'jpeg'];
            //
            if (in_array($ext, $allowed)) {
                $sourcePath = $_FILES['chat__gimage']['tmp_name']; // Storing source path of the file in a variable
                $new_name=time() . $_FILES['chat_g_image']['name'];
                $targetPath = "public/images/uploads/chat_image/" . $new_name; // Target path where file is to be stored
                if (move_uploaded_file($sourcePath, $targetPath)) {
                    $data['image']="public/images/uploads/chat_image/" . $new_name;
                } else {
                    $log['img_error'] = 'Fail to upload image!';
                }
            } else {
                $log['img_error'] = 'This file not supported!';
            }
        }else $log['empty_image']=true;
        //text process
        if(!empty($_POST['mesage'])){
            //$line=str_replace("\n","",$_POST['mesage']);
            $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
            $message=htmlentities(strip_tags($_POST['mesage']));
            if(($message) != "\n"){
                if(preg_match($reg_exUrl,$message,$url)){
                    $message=preg_replace($reg_exUrl,'<a href="'.$url[0].'" target="_blank">'.$url[0].'</a>',$message);
                }
            }
            $data['text']=$message;
        }else $log['empty_text']=true;
        //database process
        if(!empty($log['empty_image']) and !empty($log['empty_text'])) $log['empty']=true;
        else{
            $data['g_chat_id']=$_POST['g_id'];
            $data['user_id']=Auth::user()->id;
            g_chat_line::create($data);
        }
        echo json_encode($log);
    }
    //
    function create()
    {
        $log = array();
        if (!g_chat::create([
            'g_name' => $_POST['g_name'],
            'user_id' => Auth::user()->id
        ])) $log['error'] = 1;
        $g_id=g_chat::where('user_id',Auth::user()->id)->first()->id;

        user_gchat::create([
            'user_id'=>Auth::user()->id,
            'g_chat_id'=>$g_id
        ]);
        echo json_encode($log);
    }
    //
    function addMem()
    {
        $log = array();
        foreach ($_POST['user_id'] as $i) {
            if (count(user_gchat::where([
                ['user_id', $i],
                ['g_chat_id', $_POST['group_id']]
            ])->get()) == 0) {
                if (!user_gchat::create([
                    'user_id' => $i,
                    'g_chat_id' => $_POST['group_id']
                ])) $log['error'] = 1;
            }
        }
        echo json_encode($log);
    }
    //
    function load()
    {
        $log = array();
        $g_id = (int)$_POST['group_id'];
        $g_info = g_chat::find($g_id)->users;
        $log['member'] = $g_info;
        echo json_encode($log);
    }
    //
    function send_mail(){
        $log=array();
        $mailContent=array();
        //
        $mailContent['header']=$_POST['header'];
        $mailContent['text']=$_POST['text'];
        //
        $tmpPath="";
        //
        if (!empty($_FILES['mail_file']['name'])) {
            $ext = pathinfo($_FILES['mail_file']['name'], PATHINFO_EXTENSION);
            $allowed = ['png', 'jpg', 'jpeg','txt','php','json'];
            //
            if (in_array($ext, $allowed)) {
                $sourcePath = $_FILES['mail_file']['tmp_name']; // Storing source path of the file in a variable
                $new_name=time() . $_FILES['mail_file']['name'];
                $targetPath = "public/mails/uploads/" . $new_name;
                $tmpPath = "public/mails/uploads/" . $new_name ;// Target path where file is to be stored
                if (move_uploaded_file($sourcePath, $targetPath)) {
                   $fullPath=$_SERVER['SERVER_NAME']."/"."Facebook/".$targetPath;
                   $mailContent['file']="<a href='".$fullPath."'>".$new_name."</a>";
                } else {
                    $log['img_error'] = 'Fail to upload image!';
                }
            } else {
                $log['img_error'] = 'This file not supported!';
            }
        }else $log['empty_image']=true;


        $receiver  = g_chat::find((int)$_POST['g_id'])->users;
        foreach($receiver as $i){
             Mail::to($i->email)->send(new normalMail($mailContent));
         }
        if($tmpPath!="") unlink($tmpPath);
        echo json_encode($mailContent);
    }
}
