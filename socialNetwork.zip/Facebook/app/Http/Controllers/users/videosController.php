<?php

namespace App\Http\Controllers\users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class videosController extends Controller
{
    function showVideos(){
        return View('users.videos');
    }
}
