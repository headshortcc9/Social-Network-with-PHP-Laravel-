<?php

namespace App\Http\Controllers\users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\requestAdd;
use App\Models\Post;
use Illuminate\Support\Facades\Auth;
class timelineController extends Controller
{

    function showTimeline(){
        $friend_request = array();
        $tmp = requestAdd::where('receiver_id', Auth::user()->id)->get();
        foreach ($tmp as $i) {
            $u = User::find($i->sender_id);
            $arr = [
                'user_img' => $u->user_info->Avatar_pic,
                'user_name' => $u->name,
                'rel_id' => $u->id,
                'res_id' => $i->id,
                'time' => $i->created_at
            ];
            $friend_request[] = $arr;
        }
        $post = Post::where('user_id',Auth::user()->id)->get();
        $post_no = count($post);
        $suggested_friend = User::where('id','!=',Auth::user()->id)->get();
        return View('users.timeline',compact('friend_request','post_no','post','suggested_friend'));
    }
}
