<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class post_comment extends Model
{
    use HasFactory;
    protected $fillable=[
        'user_id',
        'post_id',
        'text',
        'image'
    ];

    function user(){
        return $this->belongsTo('App\Models\User');
    }
    function Post(){
        return $this->belongsTo('App\Models\Post');
    }
}
