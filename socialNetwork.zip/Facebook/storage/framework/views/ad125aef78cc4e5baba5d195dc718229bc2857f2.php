<?php $__env->startSection('sub_content'); ?>
<div class="col-lg-12">
								<div class="central-meta">
									<div class="title-block">
										<div class="row">
											<div class="col-lg-6">
												<div class="align-left">
													<h5>Photos <span>62</span></h5>
												</div>
											</div>
											<div class="col-lg-6">
												<div class="row merged20">
													<div class="col-lg-7 col-md-7 col-sm-7">
														<form method="post">
															<input type="text" placeholder="Search Photo">
															<button type="submit"><i class="fa fa-search"></i></button>
														</form>
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4">
														<div class="select-options">
															<select class="select">
																<option>Sort by</option>
																<option>A to Z</option>
																<option>See All</option>
																<option>Newest</option>
																<option>oldest</option>
															</select>
														</div>
													</div>
													<div class="col-lg-1 col-md-1 col-sm-1">
														<div class="option-list">
															<i class="fa fa-ellipsis-v"></i>
															<ul>
																<li class="active"><i class="fa fa-check"></i><a title="" href="#">Show Public</a></li>
																<li><a title="" href="#">Show only Friends</a></li>
																<li><a title="" href="#">Hide all Posts</a></li>
																<li><a title="" href="#">Mute Notifications</a></li>
															</ul>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div><!-- title block -->
								<div class="central-meta">
									<div class="row merged5">
										<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
											<div class="item-box">
												<div class="item-upload album">
													<i class="fa fa-plus-circle"></i>
													<div class="upload-meta">
														<h5>Upload photo or album</h5>
														<span>its only take a few seconds!</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
											<div class="item-box">
												<a class="strip" href="<?php echo e(asset('images/resources/photo-101.jpg')); ?>" title="" data-strip-group="mygroup" data-strip-group-options="loop: false">
												<img class='profile_img img-fluid' src="<?php echo e(asset('images/resources/default_avatar.png')); ?>" alt=""></a>
												<div class="over-photo">
													<a href="#" title=""><i class="fa fa-heart"></i> 15</a>
													<span>20 hours ago</span>
												</div>
											</div>
										</div>

									</div>

									<div class="lodmore">
										<span>Viewing 1-15 of 62 Pictures</span>
										<button class="btn-view btn-load-more"></button>
									</div>
								</div><!-- photos -->
							</div><!-- centerl meta -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/users/photos.blade.php ENDPATH**/ ?>