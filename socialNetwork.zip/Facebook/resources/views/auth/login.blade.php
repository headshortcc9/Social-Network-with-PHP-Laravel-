@extends('layouts.temp1')

@section('content')


                <div class="we-login-register">
                    <div class="form-title">
                        <i class="fa fa-key"></i>login
                        <span>sign in now and meet the awesome Friends around the world.</span>
                    </div>
                    <form class="we-form" method="post" action="{{ route('login') }}">
                        @csrf

                        <input id='email' type="text" name="email" placeholder="Email">
                        @error('email')
                        <strong>{{ $message }}</strong>
                        @enderror

                        <input type="password" name="password" placeholder="Password">
                        @error('password')
                            <strong>{{ $message }}</strong>
                        <br>
                        @enderror

                        <input type="checkbox" name="remember"><label>remember me</label>
                        <button type="submit" data-ripple="">Login</button>
                        @if (Route::has('password.request'))
                        <a class="btn btn-link" href="{{ route('password.request') }}">
                            {{ __('Forgot Your Password?') }}
                        </a>
                        @endif

                    </form>

                    <a class="with-smedia facebook" href="#" title="" data-ripple=""><i class="fa fa-facebook"></i></a>
                    <a class="with-smedia twitter" href="#" title="" data-ripple=""><i class="fa fa-twitter"></i></a>
                    <a class="with-smedia instagram" href="#" title="" data-ripple=""><i class="fa fa-instagram"></i></a>
                    <a class="with-smedia google" href="#" title="" data-ripple=""><i class="fa fa-google-plus"></i></a>
                    <span>don't have an account? <a class="we-account underline" href="register" title="">register now</a></span>
                </div>


@endsection
