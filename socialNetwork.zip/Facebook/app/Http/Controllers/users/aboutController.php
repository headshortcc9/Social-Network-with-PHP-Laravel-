<?php
namespace App\Http\Controllers\users;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\relationship;
use App\Models\User;
use App\Models\requestAdd;
use App\Models\Post;
use Illuminate\Support\Facades\Auth;
class aboutController extends Controller
{
    function showAbout(){
        $friend_request = array();
        $tmp = requestAdd::where('receiver_id', Auth::user()->id)->get();
        foreach ($tmp as $i) {
            $u = User::find($i->sender_id);
            $arr = [
                'user_img' => $u->user_info->Avatar_pic,
                'user_name' => $u->name,
                'rel_id' => $u->id,
                'res_id' => $i->id,
                'time' => $i->created_at
            ];
            $friend_request[] = $arr;
        }
        //
        $list_friend=array();
        $relationships = relationship::where('user1',Auth::user()->id)->orWhere('user2',Auth::user()->id)->get();
        foreach($relationships as $i){
            if($i->user1==Auth::user()->id) $list_friend[]=User::find($i->user2);
            else $list_friend[]=User::find($i->user1);
        }
        //list photo

        $list_photos=Post::where([
            ['user_id',Auth::user()->id],
            ['post_image','!=','']
        ])->get();
        $post_no = count(Post::where('user_id',Auth::user()->id)->get());
        return View('users.about',compact('friend_request','list_friend','list_photos','post_no'));
    }
}
