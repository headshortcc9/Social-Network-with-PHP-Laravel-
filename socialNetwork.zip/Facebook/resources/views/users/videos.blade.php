@extends('layouts.user_info')

@section('sub_content')
<div class="col-lg-12">
    <div class="central-meta">
        <div class="title-block">
            <div class="row">
                <div class="col-lg-6">
                    <div class="align-left">
                        <h5>Videos <span>49</span></h5>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row merged20">
                        <div class="col-lg-7 col-md-7 col-sm-7">
                            <form method="post">
                                <input type="text" placeholder="Search Video">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <div class="select-options">
                                <select class="select">
                                    <option>Sort by</option>
                                    <option>A to Z</option>
                                    <option>See All</option>
                                    <option>Newest</option>
                                    <option>oldest</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 col-sm-1">
                            <div class="option-list">
                                <i class="fa fa-ellipsis-v"></i>
                                <ul>
                                    <li class="active"><i class="fa fa-check"></i><a title="" href="#">Show Public</a></li>
                                    <li><a title="" href="#">Show only Friends</a></li>
                                    <li><a title="" href="#">Hide all Posts</a></li>
                                    <li><a title="" href="#">Mute Notifications</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- title block -->
    <div class="central-meta">
        <div class="row merged5">
            <div class="col-lg-12">
                <div class="featurepost">
                    <h5><i class="fa fa-fire"></i>Feature Video</h5>
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="feature-video">
                                <a href="https://www.youtube.com/watch?v=BqNgnza94Cg&ab_channel=LirikyuLirikyu" title="" data-strip-group="mygroup" class="strip" data-strip-options="width: 700,height: 450,youtube: { autoplay: 1 }">
                                    <img src="{{asset('images/resources/feature-video.jpg')}}" alt="">
                                    <i>
                                        <svg version="1.1" class="play" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" height="50px" width="50px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
                                            <path class="stroke-solid" fill="none" stroke="" d="M49.9,2.5C23.6,2.8,2.1,24.4,2.5,50.4C2.9,76.5,24.7,98,50.3,97.5c26.4-0.6,47.4-21.8,47.2-47.7
																	C97.3,23.7,75.7,2.3,49.9,2.5" />
                                            <path class="icon" fill="" d="M38,69c-1,0.5-1.8,0-1.8-1.1V32.1c0-1.1,0.8-1.6,1.8-1.1l34,18c1,0.5,1,1.4,0,1.9L38,69z" />
                                        </svg>
                                    </i>
                                </a>
                                <div class="over-photo">
                                    <a href="#" title=""><i class="fa fa-heart"></i> 15</a>
                                    <span>20 hours ago</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="feature-videometa">
                                <h4><a href="#" title="">RC Monster Truck Toy Stunts and Speed Actions free style for Kids</a></h4>
                                <p>
                                    Pro Mod R/C monster truck freestyle. Today I am tempted to run my Monster Truck 4x4, I wondered how I would handle an open difference Monster Truck in jumping races, and I was very surprised by the result. With enough speed and torque, the truck floated over it almost every time... only near the end ... there was a surprise!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
                <div class="item-box">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/u99AklNGpyc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="over-photo">
                        <a href="#" title=""><i class="fa fa-heart"></i> 15</a>
                        <span>20 hours ago</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-3 col-sm-6 col-xs-6">
                <div class="item-box">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/egy-S4gZWBI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                    <div class="over-photo">
                        <a href="#" title=""><i class="fa fa-heart"></i> 15</a>
                        <span>20 hours ago</span>
                    </div>
                </div>
            </div>

        </div>

        <div class="lodmore">
            <span>Viewing 1-15 of 47 Videos</span>
            <button class="btn-view btn-load-more"></button>
        </div>
    </div><!-- photos -->
</div><!-- centerl meta -->
@endsection
