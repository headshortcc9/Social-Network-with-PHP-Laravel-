<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>