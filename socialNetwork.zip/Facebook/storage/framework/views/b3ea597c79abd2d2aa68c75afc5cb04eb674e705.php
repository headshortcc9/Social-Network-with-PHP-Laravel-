<?php $__env->startSection('content'); ?>
<section>
    <div class="gap2 gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row merged20" id="page-contents">
                        <div class="user-profile">
                            <figure>
                                <div class="edit-pp">
                                    <label class="fileContainer">
                                        <i class="fa fa-camera"></i>
                                        <form id='change-cover-pic' action="" method="post" enctype="multipart/form-data">
                                            <input name='cover_img' data-url='<?php echo e(route('setting')); ?>' type="file">
                                            <input type="hidden" name='function' value="change-cover-pic">
                                        </form>
                                    </label>
                                </div>
                                <img class='cover_img' src="<?php echo e(asset(Auth::user()->user_info->Cover_pic)); ?>" alt="">


                            </figure>

                            <div class="profile-section">
                                <div class="row">
                                    <div class="col-lg-2 col-md-3">
                                        <div class="profile-author">
                                            <div class="profile-author-thumb">
                                                <img id='avatar-profile' class='avatar_img_x img-fluid' alt="author" src="<?php echo e(asset(Auth::user()->user_info->Avatar_pic)); ?>">
                                                <div class="edit-dp">
                                                    <label class="fileContainer">
                                                        <i class="fa fa-camera"></i>
                                                        <form id='change-avatar-pic' action="" method="post" enctype="multipart/form-data">
                                                            <input  type="file" data-url='<?php echo e(route('setting')); ?>' name='avatar_pic'>
                                                            <input type="hidden" name='function' value="change-avatar-pic">
                                                        </form>
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="author-content">
                                                <a class="h3 author-name" href="about.html"><?php echo e(Auth::user()->name); ?></a>
                                                <div class="country"><?php echo e(Auth::user()->user_info->Country); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-10 col-md-9">
                                        <ul class="profile-menu">
                                            <li>
                                                <a class="<?php if(url()->current()==url('user/timeline')) echo 'active'; ?>" href="<?php echo e(url('user/timeline')); ?>">Timeline</a>
                                            </li>
                                            <li>
                                                <a class="<?php if(url()->current()==url('user/about')) echo 'active'; ?>" href="<?php echo e(url('user/about')); ?>">About</a>
                                            </li>
                                            <li>
                                                Friends
                                            </li>
                                            <li>
                                                Photos
                                            </li>
                                            <li>
                                               Videos
                                            </li>

                                        </ul>
                                        <ol class="folw-detail">
                                            <li><span>Posts</span><ins><?php echo e($post_no); ?></ins></li>
                                            <li><span>Followers</span><ins>1.3K</ins></li>
                                            <li><span>Following</span><ins>22</ins></li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div><!-- user profile banner  -->
                        <?php echo $__env->yieldContent('sub_content'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/layouts/user_info.blade.php ENDPATH**/ ?>