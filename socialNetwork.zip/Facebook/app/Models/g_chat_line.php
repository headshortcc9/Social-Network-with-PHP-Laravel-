<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class g_chat_line extends Model
{
    use HasFactory;
    protected $fillable=[
        'user_id',
        'g_chat_id',
        'text',
        'image',
    ];
    function user(){
        return $this->belongsTo('App\Models\User');
    }
    function g_chat(){
        return $this->belongsTo('App\Models\g_chat');
    }
}
