<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUserInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_info', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->unsigned();
            $table->char('Gender',8)->nullable();
            $table->timestamp('Birthday_Date',0)->nullable();
            $table->char('job',100)->nullable();
            $table->char('hometown',100)->nullable();
            $table->char('phone_number',12)->nullable();
            $table->char('Country',100)->nullable();
            $table->text('About')->nullable();
            $table->char('Hobbies',100)->nullable();
            $table->char('Education',100)->nullable();
            $table->char('Avatar_pic',100)->default('images/resources/default_avatar.png');
            $table->char('Cover_pic',100)->default('images/resources/default_cover_pic.png');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_info');
    }
}
