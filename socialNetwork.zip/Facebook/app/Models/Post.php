<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;
    protected $table = 'posts';
    protected $fillable = [
        'post_content',
        'user_id',
        'post_image',
        'post_like',
        'post_dislike'
    ];


    function User(){
        return $this->belongsTo('App\Models\User');
    }
    function post_comment(){
        return $this->hasMany('App\Models\post_comment');
    }
}
