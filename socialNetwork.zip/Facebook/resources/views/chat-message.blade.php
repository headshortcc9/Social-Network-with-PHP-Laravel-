@extends('layouts.temp2')

@section('content')
<div class="gap2 no-gap gray-bg">
    <div class="container-fluid no-padding">
        <div class="row">
            <div id='g-chat-area' class="col-lg-12">
                <div id='create-group' class="p-2 shadow-lg rounded-1">
                    <form class='h-100 w-100'>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Group name</label><a href=""
                                class='float-lg-right'><i class='ti-close'></i></a>
                            <input type="text" name='g_name' class="form-control" id="exampleInputEmail1"
                                aria-describedby="emailHelp">
                        </div>
                        <button type="submit" id='btn-create' class="btn btn-primary">Done</button>
                    </form>
                </div>
                <div id='choose-mem' class="p-2 shadow-lg rounded-1">
                    <form class='h-100 w-100'>
                        <label class="form-label">Add friend to group</label><a href="" class='float-lg-right'><i
                                class='ti-close'></i></a>
                        <div id='list-friend'>
                            <ul>
                                @foreach($list_friend as $u)
                                <li>
                                    <div class="mb-3 form-check">
                                        <input type="checkbox" class="form-check-input" name='user_id[]'
                                            value={{$u->id}}>
                                        <label class="form-check-label" for="exampleCheck1">{{$u->name}}</label>
                                    </div>
                                </li>
                                @endforeach
                            </ul>
                        </div>
                        <input type="hidden" name="group_id" value="">
                        <button type="submit" id='btn-add' class="btn btn-primary">Done</button>
                    </form>
                </div>
                <div class="message-users">
                    <div class="message-head">
                        <h4>Chat Messages</h4>
                        <div class="more">
                            <div class="more-post-optns"><i class="ti-settings"></i>
                                <ul>
                                    <li><i class="fa fa-wrench"></i>Setting</li>
                                    <li><i class="fa fa-envelope-open"></i>Active Contacts</li>
                                    <li><i class="fa fa-folder-open"></i>Archives Chats</li>
                                    <li><i class="fa fa-eye-slash"></i>Unread Chats</li>
                                    <li><i class="fa fa-flag"></i>Report a problem</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="message-people-srch">
                        <form method="post">
                            <input type="text" placeholder="Search Friend..">
                            <button type="submit"><i class="fa fa-search"></i></button>
                        </form>
                        <div class="btn-group add-group" role="group">
                            <button id="btnGroupDrop2" type="button" class="btn group dropdown-toggle user-filter"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                All
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupDrop2">
                                <a class="dropdown-item" href="#">Online</a>
                                <a class="dropdown-item" href="#">Away</a>
                                <a class="dropdown-item" href="#">unread</a>
                                <a class="dropdown-item" href="#">archive</a>
                            </div>
                        </div>
                        <div class="btn-group add-group align-right" role="group">
                            <button id="btnGroupDrop1" type="button" class="btn group dropdown-toggle"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Create+
                            </button>
                            <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                <a class="dropdown-item" href="#">New user</a>
                                <a id='btn-new-group' class="dropdown-item" href="#">New Group +</a>
                                <a class="dropdown-item" href="#">Private Chat +</a>
                            </div>
                        </div>
                    </div>
                    <div class="mesg-peple">
                        <h5>Your group</h5>
                        <ul class="nav nav-tabs nav-tabs--vertical msg-pepl-list" id='list-owner-group'>
                            @foreach($list_group as $i)
                            <li class="nav-item unread" data-id={{$i->id}}>
                                <a class="active" href="">
                                    <figure>
                                        <img src="{{asset($i->g_image)}}" alt="">
                                        <span class="status f-online"></span>
                                    </figure>
                                    <div class="user-name">
                                        <h6 class="">{{$i->g_name}}</h6>
                                        <span>you send a video - 2hrs ago</span>
                                    </div>
                                    <div class="more">
                                        <div class="more-post-optns"><i class="ti-more-alt"></i>
                                            <ul>
                                                <li class='add-member' data-id={{$i->id}}><i
                                                        class="fa fa-user-plus"></i>Add member</li>
                                                <li class='delete-group' data-id={{$i->id}}><i
                                                        class='fa fa-sign-out'></i>Out</li>
                                            </ul>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            @endforeach
                        </ul>

                    </div>
                </div>
                <div class="tab-content messenger">
                    <div class="tab-pane active fade show" id="link1">
                        <div class="row merged">
                            <div class="col-lg-12">
                                <div class="mesg-area-head">
                                    <div class="active-user">
                                        <figure><img src="" alt="">
                                            <span class="status f-online"></span>
                                        </figure>
                                        <div>
                                            <h6 class="unread">No group choosen</h6>
                                            <span>Online</span>
                                        </div>
                                    </div>
                                    <ul class="live-calls">
                                        <li class="audio-call"><span class="fa fa-phone"></span></li>
                                        <li class="video-call"><span class="fa fa-video"></span></li>
                                        <li class="uzr-info"><span class="fa fa-info-circle"></span></li>
                                        <li>
                                            <div class="dropdown">
                                                <button class="btn" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    <i class="ti-view-grid"></i>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a id='g_send_mail' class="dropdown-item audio-call" href="#"><i
                                                            class='ti-email'></i>Send mail</a>
                                                    <a href="#" class="dropdown-item video-call"><i
                                                            class="ti-video-camera"></i>Video Call</a>
                                                    <hr>
                                                    <a href="#" class="dropdown-item"><i class="ti-server"></i>Clear
                                                        History</a>
                                                    <a href="#" class="dropdown-item"><i class="ti-hand-stop"></i>Block
                                                        Contact</a>
                                                    <a href="#" class="dropdown-item"><i class="ti-trash"></i>Delete
                                                        Contact</a>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-8 col-md-8" style="height: 745px;">
                                <div class="chat-list1 h-75" id='chat-1'>
                                    <ul id='chat-wrap' class='py-2 px-1'>

                                    </ul>
                                </div>
                                <div class="message-writing-box">
                                    <form id='g_form_chat' method="post" class="w-100">
                                        <div class="text-area">
                                            <textarea id='g_sendie' name="mesage"
                                                placeholder="Post enter to post..."></textarea>
                                            <input type="hidden" name='g_id' value="">
                                            <button type="submit"><i class="fa fa-paper-plane-o"></i></button>
                                        </div>

                                        <div class="attach-file">
                                            <label class="fileContainer">
                                                <i class="ti-clip"></i>
                                                <input type="file" id='g_chat_img' name='chat_g_image'>
                                            </label>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="chater-info">
                                    <figure><img src="" alt=""></figure>
                                    <h6>No group choosen</h6>
                                    <span>Online</span>
                                    <div class="userabout">
                                        <span>List member</span>
                                        <form id='form-send-mail' method="post">
                                            <ul style="list-style-type: none;">

                                            </ul>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div id='mail-area' class='shadow-lg'>
                    <div class="header">
                        New message
                        <a href="" class='float-lg-right'><i class='ti-close'></i></a>
                    </div>
                    <form action="" method="post">
                        <div class="form-group m-2">
                            <input type="text" class="form-control" name='header' aria-describedby="emailHelp" placeholder="Header mail">
                        </div>
                        <div class="form-group m-2">
                            <textarea class="form-control" id="exampleFormControlTextarea1" name='text' rows="10"></textarea>

                        </div>
                        <input type="hidden" name='g_id' value="">
                        <input type="file" class='form-control-file' name='mail_file'>
                        <button type="submit" class='btn btn-primary mx-2'>Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
