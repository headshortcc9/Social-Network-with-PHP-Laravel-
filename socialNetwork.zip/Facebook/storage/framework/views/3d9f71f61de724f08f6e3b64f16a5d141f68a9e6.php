<?php $__env->startSection('content'); ?>


<div class="we-login-register">
    <div class="form-title">
        <i class="fa fa-key"></i>Confirm password
        <span>Please confirm your password before continuing.</span>
    </div>
    <form class="we-form" method="post" action="<?php echo e(route('password.confirm')); ?>">
        <?php echo csrf_field(); ?>

        <input type="password" name="password" placeholder="Password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong><?php echo e($message); ?></strong>
        <br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <div>
            <button type="submit" class="btn btn-primary">
                <?php echo e(__('Confirm Password')); ?>

            </button>

            <?php if(Route::has('password.request')): ?>
            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('Forgot Your Password?')); ?>

            </a>
            <?php endif; ?>
        </div>

    </form>

    <a class="with-smedia facebook" href="#" title="" data-ripple=""><i class="fa fa-facebook"></i></a>
    <a class="with-smedia twitter" href="#" title="" data-ripple=""><i class="fa fa-twitter"></i></a>
    <a class="with-smedia instagram" href="#" title="" data-ripple=""><i class="fa fa-instagram"></i></a>
    <a class="with-smedia google" href="#" title="" data-ripple=""><i class="fa fa-google-plus"></i></a>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/auth/passwords/confirm.blade.php ENDPATH**/ ?>