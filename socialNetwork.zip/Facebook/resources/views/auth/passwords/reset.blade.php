@extends('layouts.temp1')

@section('content')


<div class="we-login-register">
    <div class="form-title">
        <i class="fa fa-key"></i>login
        <span>sign in now and meet the awesome Friends around the world.</span>
    </div>
    <form class="we-form" method="post" action="{{ route('password.update') }}">
        @csrf

        <input type="hidden" name="token" value="{{ $token }}">

        <input id='email' type="text" name="email" placeholder="Email">
        @error('email')
        <strong>{{ $message }}</strong>
        @enderror

        <input type="password" name="password" placeholder="Password">
        @error('password')
        <strong>{{ $message }}</strong>
        <br>
        @enderror

        <input id="password-confirm" type="password" name="password_confirmation" placeholder="Confirm password" required autocomplete="new-password">

        <div class="col-md-6 ">
            <button type="submit" class="btn btn-primary">
                {{ __('Reset Password') }}
            </button>
        </div>

    </form>

    <a class="with-smedia facebook" href="#" title="" data-ripple=""><i class="fa fa-facebook"></i></a>
    <a class="with-smedia twitter" href="#" title="" data-ripple=""><i class="fa fa-twitter"></i></a>
    <a class="with-smedia instagram" href="#" title="" data-ripple=""><i class="fa fa-instagram"></i></a>
    <a class="with-smedia google" href="#" title="" data-ripple=""><i class="fa fa-google-plus"></i></a>
</div>


@endsection
