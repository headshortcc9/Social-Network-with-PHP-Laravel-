<?php

use App\Models\User;
use App\Models\user_info;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;


Route::get('user/about', 'users\aboutController@showAbout')->middleware(['auth', 'password.confirm']);
Route::get('user/timeline', 'users\timelineController@showTimeline');
Route::get('user/friends', 'users\friendController@showFriends');
Route::get('user/photos', 'users\photosController@showPhotos');
Route::get('user/videos', 'users\videosController@showVideos');
Route::get('user/setting', 'users\settingController@showSetting');
Route::post("user/setting", 'users\settingController@setting')->name('setting');
Route::post("user/post", 'users\postController@createPost')->name('post');
//
Route::post("user/post/like", 'users\postController@like');
Route::post("user/post/dislike", 'users\postController@dislike');
Route::post("user/post/comment", 'users\postController@comment');
Route::post("user/post/loadComment", 'users\postController@loadComment');
//
Route::post("user/imageProcess", 'users\postController@imageProcess')->name('imageProcess');
Route::post("user/removeImage", 'users\postController@removeImage')->name('removeImage');
Route::post("user/loading", 'HomeController@loading')->name('loading');

Route::get('user/{id}', 'users\settingController@showProfile');
//
Route::get('chat-msg', 'chatController@showChat');
Route::post('chat-msg/create', 'chatController@create');
Route::post('chat-msg/add-mem', 'chatController@addMem');
Route::post('chat-msg/loadMember', 'chatController@load');
Route::post('chat-msg/get_state', 'chatController@getState');
Route::post('chat-msg/update_chat', 'chatController@update_chat');
Route::post('chat-msg/send_chat', 'chatController@send_chat');
Route::post('chat-msg/send-mail', 'chatController@send_mail');
//
Route::post('user/sendRequest','users\friendController@sendRequest')->name('sendRequest');
Route::post('user/agree','users\friendController@addFriend')->name('agree');
Route::post('user/unfriend','users\friendController@unfriend')->name('unfriend');
Route::post('user/refuse','users\friendController@refuse')->name('refuse');

//Auth
//Auth::routes(['verify' => true]);
Auth::routes();

// Route::middleware(['verified'])->group(function () {
//      Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

//      Route::get('/', 'HomeController@index');
// });

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index');
//chat
Route::post('user/get_state','users\chatController@get_state_of_chat');
Route::post('user/update_chat','users\chatController@update_chat');
Route::post('user/send_chat','users\chatController@send_chat');
Route::post('user/send_email','users\chatController@send_mail');

Route::get('/time', function () {
    return date('d-m-Y H:i:s');
});
