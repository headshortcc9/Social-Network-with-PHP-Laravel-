<?php $__env->startSection('sub_content'); ?>
<div class="col-lg-12">
    <div class="central-meta">
        <div class="title-block">
            <div class="row">
                <div class="col-lg-6">
                    <div class="align-left">
                        <h5>Friend / Followers <span>30</span></h5>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row merged20">
                        <div class="col-lg-7 col-md-7 col-sm-7">
                            <form method="post">
                                <input type="text" placeholder="Search Friend">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4">
                            <div class="select-options">
                                <select class="select">
                                    <option>Sort by</option>
                                    <option>A to Z</option>
                                    <option>See All</option>
                                    <option>Newest</option>
                                    <option>oldest</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-1 col-md-1 col-sm-1">
                            <div class="option-list">
                                <i class="fa fa-ellipsis-v"></i>
                                <ul>
                                    <li><a title="" href="#">Show Friends Public</a></li>
                                    <li><a title="" href="#">Show Friends Private</a></li>
                                    <li><a title="" href="#">Mute Notifications</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- title block -->
    <div class="central-meta padding30">
        <div class="row merged20">
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="friend-block">
                    <div class="more-opotnz">
                        <i class="fa fa-ellipsis-h"></i>
                        <ul>
                            <li><a href="#" title="">Block</a></li>
                            <li><a href="#" title="">UnBlock</a></li>
                            <li><a href="#" title="">Mute Notifications</a></li>

                        </ul>
                    </div>
                    <figure>
                        <img src="<?php echo e(asset('images/resources/default_avatar.png')); ?>" alt="">
                    </figure>

                    <div class="frnd-meta">
                        <div class="frnd-name">
                            <a href="#" title="">Adam James</a>
                            <span>Los Angeles, CA</span>
                        </div>
                        <a class="send-mesg" href="#" title="">Message</a>
                    </div>
                </div>
            </div>

        </div>
        <div class="lodmore">
            <span>Viewing 1-16 of 30 friends</span>
            <button class="btn-view btn-load-more"></button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/users/friend.blade.php ENDPATH**/ ?>