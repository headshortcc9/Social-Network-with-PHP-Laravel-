<div class="gap2 gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row merged20" id="page-contents">
                    <div class="col-lg-2">
                        <aside class="sidebar static left">
                            <div class="advertisment-box">
                                <h4 class="">advertisment</h4>
                                <figure class="bg-dark">
                                    <a href="#" title="Advertisment"><img src="{{asset('images/resources/tt.gif')}}" alt=""></a>
                                </figure>
                            </div>
                            <div class="widget">
                                <h4 class="widget-title">Shortcuts</h4>
                                <ul class="naves">
                                    <li>
                                        <i class="ti-clipboard"></i>
                                        <a href="" title="">News feed</a>
                                    </li>
                                    <li>
                                        <i class="ti-mouse-alt"></i>
                                        <a href="" title="">Inbox</a>
                                    </li>
                                    <li>
                                        <i class="ti-files"></i>
                                        <a href="" title="">My pages</a>
                                    </li>
                                    <li>
                                        <i class="ti-user"></i>
                                        <a href="user/friends" title="">friends</a>
                                    </li>
                                    <li>
                                        <i class="ti-image"></i>
                                        <a href="user/photos" title="">images</a>
                                    </li>
                                    <li>
                                        <i class="ti-video-camera"></i>
                                        <a href="user/videos" title="">videos</a>
                                    </li>
                                    <li>
                                        <i class="ti-comments-smiley"></i>
                                        <a href="" title="">Messages</a>
                                    </li>
                                    <li>
                                        <i class="ti-bell"></i>
                                        <a href="" title="">Notifications</a>
                                    </li>
                                    <li>
                                        <i class="ti-share"></i>
                                        <a href="" title="">People Nearby</a>
                                    </li>
                                    <li>
                                        <i class="fa fa-bar-chart-o"></i>
                                        <a href="" title="">insights</a>
                                    </li>

                                </ul>
                            </div>
                        </aside>
                    </div>
                    <!-- sidebar -->
                    <div class="col-lg-8">

                        <div class="central-meta postbox">
                            <span class="create-post">Create post</span>
                            <div class="new-postbox">
                                <figure>
                                    <img class='avatar_img' src=" {{asset(Auth::user()->user_info->Avatar_pic)}}" alt="">
                                </figure>
                                <div class="newpst-input">
                                    <form method="post">
                                        <textarea rows="2" placeholder="Share some what you are thinking?"></textarea>
                                    </form>
                                </div>
                                <div class="attachments">
                                    <ul>
                                        <li>
                                            <span class="add-loc">
                                                <i class="fa fa-map-marker"></i>
                                            </span>
                                        </li>
                                        <li>
                                            <i class="fa fa-music"></i>
                                            <label class="fileContainer">
                                                <input type="file">
                                            </label>
                                        </li>
                                        <li>
                                            <i class="fa fa-image"></i>
                                            <label class="fileContainer">
                                                <input type="file">
                                            </label>
                                        </li>
                                        <li>
                                            <i class="fa fa-video-camera"></i>
                                            <label class="fileContainer">
                                                <input type="file">
                                            </label>
                                        </li>
                                        <li>
                                            <i class="fa fa-camera"></i>
                                            <label class="fileContainer">
                                                <input type="file">
                                            </label>
                                        </li>
                                        <li class="preview-btn">
                                            <button class="post-btn-preview" type="submit" data-ripple="">Preview</button>
                                        </li>
                                    </ul>
                                    <button class="post-btn" type="submit" data-ripple="">Post</button>
                                </div>
                                <div class="add-location-post">
                                    <span>Drag map point to selected area</span>
                                    <div class="row">

                                        <div class="col-lg-6">
                                            <label class="control-label">Lat :</label>
                                            <input type="text" class="" id="us3-lat" />
                                        </div>
                                        <div class="col-lg-6">
                                            <label>Long :</label>
                                            <input type="text" class="" id="us3-lon" />
                                        </div>
                                    </div>
                                    <!-- map -->
                                    <div id="us3"></div>
                                </div>
                            </div>
                        </div><!-- add post new box -->
                        <div class="central-meta">
                            <span class="create-post">Recent Stories <a href="#" title="">See All</a></span>
                            <div class="story-postbox">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/Viego1.jpg')}}" alt="">
                                                <span>Add Your Story</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="{{Auth::user()->name}}">
                                                <i class="fa fa-plus"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/Yone1.jpg')}}" alt="">
                                                <span>Yone</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Yone">
                                                <img src=" {{asset('images/resources/yone2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/kaisa1.jpg')}}" alt="">
                                                <span>Kaisa</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Kaisa">
                                                <img src=" {{asset('images/resources/kaisa2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-3">
                                        <div class="story-box">
                                            <figure>
                                                <img src=" {{asset('images/resources/darius1.jpg')}}" alt="">
                                                <span>Darius</span>
                                            </figure>
                                            <div class="story-thumb" data-toggle="tooltip" title="Darius">
                                                <img src=" {{asset('images/resources/darius2.jpg')}}" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- top stories -->
                        <div class="loadMore">
                            <div class="central-meta item">
                                <div class="user-post">
                                    <div class="friend-info">
                                        <figure>
                                            <img src=" {{asset('images/resources/nearly1.jpg')}}" alt="">
                                        </figure>
                                        <div class="friend-name">
                                            <div class="more">
                                                <div class="more-post-optns"><i class="ti-more-alt"></i>
                                                    <ul>
                                                        <li><i class="fa fa-pencil-square-o"></i>Edit Post</li>
                                                        <li><i class="fa fa-trash-o"></i>Delete Post</li>
                                                        <li class="bad-report"><i class="fa fa-flag"></i>Report Post</li>
                                                        <li><i class="fa fa-address-card-o"></i>Boost This Post</li>
                                                        <li><i class="fa fa-clock-o"></i>Schedule Post</li>
                                                        <li><i class="fa fa-wpexplorer"></i>Select as featured</li>
                                                        <li><i class="fa fa-bell-slash-o"></i>Turn off Notifications</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <ins><a href="time-line.html" title="">Jack Carter</a> Post Album</ins>
                                            <span><i class="fa fa-globe"></i> published: September,15 2020 19:PM </span>
                                        </div>
                                        <!--Post-info-->

                                        <div class="post-meta">
                                            <p>
                                                Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero.
                                            </p> <!-- Text -->
                                            <figure>
                                                <div class="img-bunch">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                                    <img src=" {{asset('images/resources/album1.jpg')}}" alt="">
                                                                </a>
                                                            </figure>
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                                    <img src=" {{asset('images/resources/album2.jpg')}}" alt="">
                                                                </a>
                                                            </figure>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                                    <img src=" {{asset('images/resources/album6.jpg')}}" alt="">
                                                                </a>
                                                            </figure>
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                                    <img src=" {{asset('images/resources/album5.jpg')}}" alt="">
                                                                </a>
                                                            </figure>
                                                            <figure>
                                                                <a href="#" title="" data-toggle="modal" data-target="#img-comt">
                                                                    <img src=" {{asset('images/resources/album4.jpg')}}" alt="">
                                                                </a>
                                                                <div class="more-photos">
                                                                    <span>+15</span>
                                                                </div>
                                                            </figure>
                                                        </div>
                                                    </div>
                                                </div> <!-- images -->
                                                <ul class="like-dislike">
                                                    <li><a class="bg-purple" href="#" title="Save to Pin Post"><i class="fa fa-thumb-tack"></i></a></li>
                                                    <li><a class="bg-blue" href="#" title="Like Post"><i class="ti-thumb-up"></i></a></li>
                                                    <li><a class="bg-red" href="#" title="dislike Post"><i class="ti-thumb-down"></i></a></li>
                                                </ul> <!-- Reaction -->
                                            </figure>
                                            <div class="we-video-info">
                                                <ul>
                                                    <li>
                                                        <span class="views" title="views">
                                                            <i class="fa fa-eye"></i>
                                                            <ins>1.2k</ins>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <div class="likes heart" title="Like/Dislike">❤ <span>2K</span></div>
                                                    </li>
                                                    <li>
                                                        <span class="comment" title="Comments">
                                                            <i class="fa fa-commenting"></i>
                                                            <ins>52</ins>
                                                        </span>
                                                    </li>

                                                    <li>
                                                        <span>
                                                            <a class="share-pst" href="#" title="Share">
                                                                <i class="fa fa-share-alt"></i>
                                                            </a>
                                                            <ins>20</ins>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </div> <!-- Video -->
                                        </div>
                                        <!--Post-content-->

                                        <div class="coment-area" style="display: block;">
                                            <ul class="we-comet">
                                                <li>
                                                    <div class="comet-avatar">
                                                        <img src=" {{asset('images/resources/nearly3.jpg')}}" alt="">
                                                    </div>
                                                    <div class="we-comment">
                                                        <h5><a href="time-line.html" title="">Jason borne</a></h5>
                                                        <p>we are working for the dance and sing songs. this video is very awesome for the youngster. please vote this video and like our channel</p>
                                                        <div class="inline-itms">
                                                            <span>1 year ago</span>
                                                            <a class="we-reply" href="#" title="Reply"><i class="fa fa-reply"></i></a>
                                                            <a href="#" title=""><i class="fa fa-heart"></i><span>20</span></a>
                                                        </div>
                                                    </div>

                                                </li>
                                                <li>
                                                    <div class="comet-avatar">
                                                        <img src=" {{asset('images/resources/comet-4.jpg')}}" alt="">
                                                    </div>
                                                    <div class="we-comment">
                                                        <h5><a href="time-line.html" title="">Sophia</a></h5>
                                                        <p>we are working for the dance and sing songs. this video is very awesome for the youngster.
                                                            <i class="em em-smiley"></i>
                                                        </p>
                                                        <div class="inline-itms">
                                                            <span>1 year ago</span>
                                                            <a class="we-reply" href="#" title="Reply"><i class="fa fa-reply"></i></a>
                                                            <a href="#" title=""><i class="fa fa-heart"></i><span>20</span></a>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li>
                                                    <a href="#" title="" class="showmore underline">more comments+</a>
                                                </li>
                                                <li class="post-comment">
                                                    <div class="comet-avatar">
                                                        <img src=" {{asset('images/resources/nearly1.jpg')}}" alt="">
                                                    </div>
                                                    <div class="post-comt-box">
                                                        <form method="post">
                                                            <textarea placeholder="Post your comment"></textarea>
                                                            <div class="add-smiles">
                                                                <div class="uploadimage">
                                                                    <i class="fa fa-image"></i>
                                                                    <label class="fileContainer">
                                                                        <input type="file">
                                                                    </label>
                                                                </div>
                                                                <span class="em em-expressionless" title="add icon"></span>
                                                                <div class="smiles-bunch">
                                                                    <i class="em em---1"></i>
                                                                    <i class="em em-smiley"></i>
                                                                    <i class="em em-anguished"></i>
                                                                    <i class="em em-laughing"></i>
                                                                    <i class="em em-angry"></i>
                                                                    <i class="em em-astonished"></i>
                                                                    <i class="em em-blush"></i>
                                                                    <i class="em em-disappointed"></i>
                                                                    <i class="em em-worried"></i>
                                                                    <i class="em em-kissing_heart"></i>
                                                                    <i class="em em-rage"></i>
                                                                    <i class="em em-stuck_out_tongue"></i>
                                                                </div>
                                                            </div>

                                                            <button type="submit"></button>
                                                        </form>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>
                            </div><!-- album post -->

                        </div>
                    </div><!-- centerl meta -->

                </div>
            </div>
        </div>
    </div>
</div>
