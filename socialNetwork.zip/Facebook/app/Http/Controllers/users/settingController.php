<?php

namespace App\Http\Controllers\users;

use App\Http\Controllers\Controller;
use App\Models\relationship;
use App\Models\user_info;
use App\Models\User;
use App\Models\Post;
use App\Models\requestAdd;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class settingController extends Controller
{
    function showSetting()
    {
        //load request
        $friend_request = array();
        $tmp = requestAdd::where('receiver_id', Auth::user()->id)->get();
        foreach ($tmp as $i) {
            $u = User::find($i->sender_id);
            $arr = [
                'user_img' => $u->user_info->Avatar_pic,
                'user_name' => $u->name,
                'rel_id' => $u->id,
                'res_id' => $i->id,
                'time' => $i->created_at
            ];
            $friend_request[] = $arr;
        }
        $post_no = count(Post::where('user_id',Auth::user()->id)->get());
        return View('users.setting', compact('friend_request','post_no'));
    }

    function showProfile($id)
    {
        $info = User::find($id);
        $is_friend = 0;
        $action = relationship::where([
            ['user1', $id],
            ['user2', Auth::user()->id]
        ])->orWhere([
            ['user2', $id],
            ['user1', Auth::user()->id]
        ])->get();
        if (count($action) > 0) $is_friend = 1;
        if (empty($info)) return "Can't find user !";
        else return View('users.profile', compact('info', 'is_friend'));
    }

    function setting()
    {
        $func = $_POST['function'];
        $log = array();

        switch ($func) {
            case ('change-avatar-pic'):
                $ext = pathinfo($_FILES['avatar_pic']['name'], PATHINFO_EXTENSION);
                $allowed = ['png', 'jpg', 'jpeg'];
                //
                if (in_array($ext, $allowed)) {
                    $sourcePath = $_FILES['avatar_pic']['tmp_name']; // Storing source path of the file in a variable
                    $targetPath = "public/images/uploads/" . Auth::user()->root_folder . '/' . 'avatar-' . $_FILES['avatar_pic']['name']; // Target path where file is to be stored
                    $log['sourcePath'] = $sourcePath;
                    $log['targetPath'] = $targetPath;
                    if (move_uploaded_file($sourcePath, $targetPath)) {
                        if (Auth::user()->user_info->Avatar_pic != 'images/resources/default_avatar.png') {
                            unlink("public/" . Auth::user()->user_info->Avatar_pic);
                        }
                        user_info::where('user_id', Auth::user()->id)->update([
                            'Avatar_pic' => "images/uploads/" . Auth::user()->root_folder . '/' . 'avatar-' . $_FILES['avatar_pic']['name'],
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                        $log['error'] = null;
                        $log['avatar_pic'] = "../public/images/uploads/" . Auth::user()->root_folder . '/' . 'avatar-' . $_FILES['avatar_pic']['name'];
                    } else {
                        $log['error'] = 'Fail!!';
                    }
                } else {
                    $log['error'] = 'File not allow!';
                }


                break;
            case ('change-cover-pic'):
                $ext = pathinfo($_FILES['cover_img']['name'], PATHINFO_EXTENSION);
                $allowed = ['png', 'jpg', 'jpeg'];

                //
                if (in_array($ext, $allowed)) {
                    $sourcePath = $_FILES['cover_img']['tmp_name']; // Storing source path of the file in a variable
                    $targetPath = "public/images/uploads/" . Auth::user()->root_folder . '/' . 'cover-' . $_FILES['cover_img']['name']; // Target path where file is to be stored
                    $log['sourcePath'] = $sourcePath;
                    $log['targetPath'] = $targetPath;
                    if (move_uploaded_file($sourcePath, $targetPath)) {
                        if (Auth::user()->user_info->Cover_pic != 'images/resources/default_cover_pic.png') {
                            unlink("public/" . Auth::user()->user_info->Cover_pic);
                        }

                        user_info::where('user_id', Auth::user()->id)->update([
                            'Cover_pic' => "images/uploads/" . Auth::user()->root_folder . '/' . 'cover-' . $_FILES['cover_img']['name'],
                            'updated_at' => date('Y-m-d H:i:s')
                        ]);
                        $log['error'] = null;
                        $log['cover_img'] = "../public/images/uploads/" . Auth::user()->root_folder . '/' . 'cover-' . $_FILES['cover_img']['name'];
                    } else {
                        $log['error'] = 'Fail!!';
                    }
                } else {
                    $log['error'] = 'File not allow!';
                }
                break;

            case ('edit-profile'):
                $data_info = array();
                $data_user = array();
                foreach ($_POST as $key => $value) {
                    if (!empty($value)) {
                        if ($key != 'name' and $key != 'email') {
                            $data_info[$key] = htmlentities($value);
                        } else {
                            $data_user[$key] = htmlentities($value);
                        }
                    }
                }

                unset($data_user['function']);
                unset($data_info['function']);
                if (!empty($data_info)) {
                    $data_info['updated_at'] = date('Y-m-d H:i:s');
                    user_info::where('user_id', Auth::user()->id)->update($data_info);
                }
                if (!empty($data_user)) {
                    $data_user['updated_at'] = date('Y-m-d H:i:s');
                    if (array_key_exists('email', $data_user)) {
                        if (User::where('email', $data_user['email'])->first()) {
                            $log['error'] = 'This email is already in use';
                        } else {
                            $data_user['email_verified_at'] = null;
                        }
                    }
                    if (empty($log['error'])) {
                        User::where('id', Auth::user()->id)->update($data_user);
                    }
                }


                $log['post1'] = $data_user;
                $log['post2'] = $data_info;
                break;
        }

        echo json_encode($log);
    }
}
