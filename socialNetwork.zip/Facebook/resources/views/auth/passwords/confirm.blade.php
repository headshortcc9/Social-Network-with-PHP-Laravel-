@extends('layouts.temp1')

@section('content')


<div class="we-login-register">
    <div class="form-title">
        <i class="fa fa-key"></i>Confirm password
        <span>Please confirm your password before continuing.</span>
    </div>
    <form class="we-form" method="post" action="{{ route('password.confirm') }}">
        @csrf

        <input type="password" name="password" placeholder="Password">
        @error('password')
        <strong>{{ $message }}</strong>
        <br>
        @enderror


        <div>
            <button type="submit" class="btn btn-primary">
                {{ __('Confirm Password') }}
            </button>

            @if (Route::has('password.request'))
            <a class="btn btn-link" href="{{ route('password.request') }}">
                {{ __('Forgot Your Password?') }}
            </a>
            @endif
        </div>

    </form>

    <a class="with-smedia facebook" href="#" title="" data-ripple=""><i class="fa fa-facebook"></i></a>
    <a class="with-smedia twitter" href="#" title="" data-ripple=""><i class="fa fa-twitter"></i></a>
    <a class="with-smedia instagram" href="#" title="" data-ripple=""><i class="fa fa-instagram"></i></a>
    <a class="with-smedia google" href="#" title="" data-ripple=""><i class="fa fa-google-plus"></i></a>

</div>


@endsection
