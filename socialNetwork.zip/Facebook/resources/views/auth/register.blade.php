@extends('layouts.temp1')

@section('content')

<div class="we-login-register">
    <div class="form-title">
        <i class="fa fa-key"></i>Sign Up
        <span>Sign Up now and meet the awesome friends around the world.</span>
    </div>
    <form class="we-form" method="post" action="{{ route('register') }}">
        @csrf

        <input type="text" name='name' placeholder="Fullname">
        @error('name')
        <strong>{{ $message }}</strong>
        @enderror

        <input type="text" placeholder="Email" name='email'>
        @error('email')
        <strong>{{ $message }}</strong><br>
        @enderror

        <input type="password" placeholder="Password" name='password' required autocomplete="new-password">
        @error('password')
        <strong>{{ $message }}</strong>
        @enderror

        <input type="password" placeholder="Password confirm" name="password_confirmation" required autocomplete="new-password">
        <button type="submit" data-ripple="">Register</button>
    </form>
    <a data-ripple="" title="" href="#" class="with-smedia facebook"><i class="fa fa-facebook"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia twitter"><i class="fa fa-twitter"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia instagram"><i class="fa fa-instagram"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia google"><i class="fa fa-google-plus"></i></a>
    <span>already have an account? <a class="we-account underline" href="{{route("login")}}" title="">Sign in</a></span>
</div>

@endsection
