<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class user_info extends Model
{
    protected $table = 'user_info';
    use HasFactory;
    //
    protected $fillable = [
        'user_id'

    ];
    protected function User(){
        return $this->belongsTo('User');
    }

}
