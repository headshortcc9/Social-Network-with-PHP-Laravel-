<?php $__env->startSection('content'); ?>

<div class="we-login-register">
    <div class="form-title">
        <i class="fa fa-key"></i>Sign Up
        <span>Sign Up now and meet the awesome friends around the world.</span>
    </div>
    <form class="we-form" method="post" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>

        <input type="text" name='name' placeholder="Fullname">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="text" placeholder="Email" name='email'>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong><?php echo e($message); ?></strong><br>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="password" placeholder="Password" name='password' required autocomplete="new-password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="password" placeholder="Password confirm" name="password_confirmation" required autocomplete="new-password">
        <button type="submit" data-ripple="">Register</button>
    </form>
    <a data-ripple="" title="" href="#" class="with-smedia facebook"><i class="fa fa-facebook"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia twitter"><i class="fa fa-twitter"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia instagram"><i class="fa fa-instagram"></i></a>
    <a data-ripple="" title="" href="#" class="with-smedia google"><i class="fa fa-google-plus"></i></a>
    <span>already have an account? <a class="we-account underline" href="<?php echo e(route("login")); ?>" title="">Sign in</a></span>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.temp1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nguyengia/hdd/Server01/site1/Facebook/resources/views/auth/register.blade.php ENDPATH**/ ?>